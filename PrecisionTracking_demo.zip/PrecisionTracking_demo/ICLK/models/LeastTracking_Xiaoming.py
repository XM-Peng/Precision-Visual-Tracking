import torch
import torch.nn as nn
import torch.nn.functional as F
import numpy as np

from ICLK.models.submodules import convLayer as conv
from ICLK.models.submodules import color_normalize

from ICLK.models.algorithms_Xiaoming import TrustRegionBase as TrustRegion
from ICLK.models.algorithms_Xiaoming import DirectSolverNet, FeaturePyramid, DeepRobustEstimator


class LeastSquareTracking(nn.Module):

    def __init__(self, max_iter_per_pyr,
                 mEst_type,
                 alpha,
                 solver_type,
                 timers=None):

        super(LeastSquareTracking, self).__init__()
        self.timers = timers
        self.encoder = FeaturePyramid(D=3)

        """             Initialize the Robust Estimator                     """
        self.mEst_func = DeepRobustEstimator(mEst_type)
        mEst_funcs = [self.mEst_func, self.mEst_func, self.mEst_func,
                      self.mEst_func]

        self.solver_func = DirectSolverNet(solver_type)
        solver_funcs = [self.solver_func, self.solver_func,
                        self.solver_func, self.solver_func]

        """ =============================================================== """
        """             Initialize the Trust-Region Method                  """
        """ =============================================================== """

        self.tr_update0 = TrustRegion(max_iter_per_pyr,
                                      mEst_func=mEst_funcs[0],
                                      alpha = alpha[0],
                                      solver_func=solver_funcs[0],
                                      timers=timers)
        self.tr_update1 = TrustRegion(max_iter_per_pyr,
                                      mEst_func=mEst_funcs[1],
                                      alpha = alpha[1],
                                      solver_func=solver_funcs[1],
                                      timers=timers)
        self.tr_update2 = TrustRegion(max_iter_per_pyr,
                                      mEst_func=mEst_funcs[2],
                                      alpha = alpha[2],
                                      solver_func=solver_funcs[2],
                                      timers=timers)
        self.tr_update3 = TrustRegion(max_iter_per_pyr,
                                      mEst_func=mEst_funcs[3],
                                      alpha = alpha[3],
                                      solver_func=solver_funcs[3],
                                      timers=timers)

    def forward(self, img0, mask0, img1, intpose):
        """
               :input
               :param the reference image
               :param the target image
               :param the inverse depth of the reference image
               :param the inverse depth of the target image
               :param the pin-hole camera instrinsic (in vector) [fx, fy, cx, cy]
               :param the initial pose [Rotation, translation]
               --------
               :return
               :param estimated transform
               """
        x0 = self.__encode_features(img0)
        x1 = self.__encode_features(img1)

        poses_to_train = []  # 2D Affine
        B = img0.shape[0]
        if intpose.dim() != 3:
            # 将 intpose扩展为 (B, 3, 3)，即对batch中的每个样本都赋给一个3x3的矩阵，其值与intpose一样
            poseI = intpose.expand(B, 3, 3).type_as(img0)
        else:
            poseI = intpose.clone()

        if mask0 is None:
            if torch.cuda.is_available():
                mask0 = torch.ones(B, 1, img0.shape[-2], img0.shape[-1]).type_as(img0).cuda()
            else:
                mask0 = torch.ones(B, 1, img0.shape[-2], img0.shape[-1]).type_as(img0)

        # 处理img0的mask
        mask0_pyramid = self.__mask_pyramid(mask0)

        """
        output3 = self.tr_update3(poseI, x0[3], x1[3], prior_W)
        pose3, mEst_W3 = output3[0], output3[1]
        poses_to_train.append(pose3)  # add a new object
        # trust region update on level 2
        pose3_2 = self.__pose_pymarids(pose3)
        """
        # 在初始估计是poseI时候获得对变换的更新
        pose2 = self.tr_update2(poseI, x0[2], mask0_pyramid[2], x1[2])
        # trust region update on level 1
        # pose2参数传播到上一级
        pose2_1 = self.__pose_pymarids(pose2)
        pose2_0 = self.__pose_pymarids(pose2_1)
        poses_to_train.append(pose2_0)

        pose1 = self.tr_update1(pose2_1, x0[1], mask0_pyramid[1], x1[1])
        # pose1参数传播到上一级
        pose1_0 = self.__pose_pymarids(pose1)
        poses_to_train.append(pose1_0)

        # trust-region update on the raw scale
        pose0 = self.tr_update0(pose1_0, x0[0], mask0_pyramid[0], x1[0])
        poses_to_train.append(pose0)  # Last modify 12.24

        if self.timers: self.timers.toc('trust-region update')
        return pose0
        # if self.training:
        #     pyr_R = torch.stack(tuple(poses_to_train), dim=1)
        #     return pyr_R
        # else:
        #     return pose0


    def __encode_features(self, I):
        x = self.encoder.forward(I)
        x = [self.__Nto1(a) for a in x]
        return x


    """
    def __encode_features(self, I):
        x = self.__color3to1(I)
        x = self.encoder.forward(x)
        x = [self.__Nto1(a) for a in x]
        return x
    """

    """
    def __encode_features(self, I):
        x = self.__color3to1(I)
        x = self.encoder.forward(x)
        return x

    """

    """
    def __encode_features(self, I):
        x = self.encoder.forward(I)
        return x
    """

    def __Nto1(self, x):
        """ Take the average of multi-dimension feature into one dimensional,
            which boostrap the optimization speed
        """
        C = x.shape[1]
        return x.sum(dim=1, keepdim=True) / C

    def __color3to1(self, img):
        """ Return a gray-scale image
        """
        B, _, H, W = img.shape
        return (img[:, 0] * 0.299 + img[:, 1] * 0.587 + img[:, 2] * 0.114).view(B, 1, H, W)

    def __pose_pymarids(self, pose):
        B = pose.shape[0]
        Part_1 = pose[:, :2, :2].view(B, 2, 2)
        Part_2 = pose[:, :2, 2].view(B, 2, 1)
        Part_3 = pose[:, 2, :2].view(B, 1, 2)
        Part_4 = pose[:, 2, 2].view(B, 1, 1)
        pose_pz = torch.cat((torch.cat((Part_1, Part_2*2), dim=2),
                            torch.cat((Part_3/2, Part_4), dim=2)), dim=1)
        return pose_pz

    def __mask_pyramid(self, mask):
        original_mask_sz = mask.shape[-2:]
        mask0 = mask.clone()

        sz = [s//2 for s in original_mask_sz]
        mask1 = F.interpolate(mask, sz)

        sz = [s//4 for s in original_mask_sz]
        mask2 = F.interpolate(mask, sz)

        sz = [s//8 for s in original_mask_sz]
        mask3 = F.interpolate(mask, sz)

        return mask0, mask1, mask2, mask3





