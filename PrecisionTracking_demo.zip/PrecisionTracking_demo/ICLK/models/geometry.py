from __future__ import absolute_import
from __future__ import division
from __future__ import print_function
from __future__ import unicode_literals

import torch
import torch.nn as nn
from torch import sin, cos, atan2, acos
import torch.nn.functional

def meshgrid(H, W, B=None, is_cuda=False):
    """ torch version of numpy meshgrid function

    :input
    :param height
    :param width
    :param batch size
    :param initialize a cuda tensor if true
    -------
    :return
    :param meshgrid in column
    :param meshgrid in row
    """
    u = torch.arange(0, W)
    v = torch.arange(0, H)

    if is_cuda:
        u, v = u.cuda(), v.cuda()

    u = u.repeat(H, 1).view(1,H,W)
    v = v.repeat(W, 1).t_().view(1,H,W)

    if B is not None:
        u, v = u.repeat(B,1,1,1), v.repeat(B,1,1,1)
    return u, v

def generate_xy_grid(B, H, W):
    """ Generate a batch of image grid from image space to world space
        px = (u - cx) / fx
        py = (y - cy) / fy

        function tested in 'test_geometry.py'

    :input
    :param batch size
    :param height
    :param width
    :param camera intrinsic array [fx,fy,cx,cy]
    ---------
    :return
    :param
    :param
    """
    cx = torch.tensor([[9.9844]]).cuda()
    # cx = torch.tensor([[9.9844]])
    uv_grid = meshgrid(H, W, B)
    u_grid, v_grid = [uv.type_as(cx) for uv in uv_grid] # cols and rows

    return u_grid, v_grid

def batch_warp_affine(pu, pv, affine):
    # A = affine[:,:,:2]
    # t = affine[:,:, 2]
    B,_,H,W = pu.shape
    ones = torch.ones(pu.shape).type_as(pu)
    uv = torch.cat((pu, pv, ones), dim=1)
    uv = torch.bmm(affine, uv.view(B,3,-1)) #+ t.view(B,2,1)
    return uv[:,0].view(B,1,H,W), uv[:,1].view(B,1,H,W)

def batch_warp_homo(pu, pv, homo):
    # A = affine[:,:,:2]
    # t = affine[:,:, 2]
    B,_,H,W = pu.shape
    ones = torch.ones(pu.shape).type_as(pu)
    uv = torch.cat((pu, pv, ones), dim=1)
    uv = torch.bmm(homo, uv.view(B,3,-1)) #+ t.view(B,2,1)
    uv0 = uv[:,0]/uv[:,2]
    uv1 = uv[:,1]/uv[:,2]
    return uv0.view(B,1,H,W), uv1.view(B,1,H,W)

def warp_features(F, u, v):
    """
    Warp the feature map (F) w.r.t. the grid (u, v)
    """
    B, C, H, W = F.shape
    B1, C1, H1, W1 = u.shape
    u_norm = u / ((W-1)/2) - 1
    v_norm = v / ((H-1)/2) - 1
    uv_grid = torch.cat((u_norm.view(B1,H1,W1,1), v_norm.view(B1,H1,W1,1)), dim=3)
    # F_warped = torch.nn.functional.grid_sample(F, uv_grid,
    #  mode='bilinear', padding_mode='border')
    F_warped = torch.nn.functional.grid_sample(F, uv_grid,
                                               mode='bilinear', padding_mode='border', align_corners=True)
    return F_warped

def Homo_inverse(twist):
    B = twist.size()[0]
    p1 = twist[:, 0, :].view(B, 1, 1)
    p2 = twist[:, 1, :].view(B, 1, 1)
    p3 = twist[:, 2, :].view(B, 1, 1)
    p4 = twist[:, 3, :].view(B, 1, 1)
    p5 = twist[:, 4, :].view(B, 1, 1)
    p6 = twist[:, 5, :].view(B, 1, 1)
    p7 = twist[:, 6, :].view(B, 1, 1)
    p8 = twist[:, 7, :].view(B, 1, 1)
    det_twist = torch.cat((torch.cat((1+p1, p3, p5), dim=2),
                           torch.cat((p2, 1+p4, p6), dim=2),
                           torch.cat((p7, p8, torch.ones(B, 1, 1).cuda()), dim=2)), dim=1)
    # det = torch.det(det_twist)
    # den = ((1 + p1) * (1 + p4) - p2 * p3)*det
    # invp1 = (1 + p4 - p6*p8 - den) / den
    # invp2 = (-p2 + p6*p7) / den
    # invp3 = (-p3 + p5*p8) / den
    # invp4 = (1 + p1 - p5*p7 - den) / den
    # invp5 = (-p5 - p4*p5 + p3*p6) / den
    # invp6 = (-p6 - p1*p6 + p2*p5) / den
    # invp7 = (-p7 - p4 * p7 + p2 * p8) / den
    # invp8 = (-p8 - p1 * p8 + p3 * p7) / den
    # inv_twist = torch.cat((torch.cat((1+invp1, invp3, invp5), dim=2),
    #                        torch.cat((invp2, 1+invp4, invp6), dim=2),
    #                        torch.cat((invp7, invp8, torch.ones(B, 1, 1).cuda()), dim=2)), dim=1)

    return det_twist

def Homo_compose(pose, invp):
    B = pose.size()[0]
    p19 = invp[:, 2, 2].view(B,1,1)
    p19 = p19.repeat(1,3,3)
    ip = invp/p19
    pre_pose = torch.bmm(pose, ip)
    p9 = pre_pose[:, 2, 2].view(B,1,1)
    p9 = p9.repeat(1,3,3)
    new_pose = pre_pose/p9
    return new_pose
    # p1 = (pose[:, 0, 0]-1).view(B, 1, 1)
    # p3 = pose[:, 0, 1].view(B, 1, 1)
    # p5 = pose[:, 0, 2].view(B, 1, 1)
    # p2 = pose[:, 1, 0].view(B, 1, 1)
    # p4 = (pose[:, 1, 1]-1).view(B, 1, 1)
    # p6 = pose[:, 1, 2].view(B, 1, 1)
    # p7 = pose[:, 2, 0].view(B, 1, 1)
    # p8 = pose[:, 2, 1].view(B, 1, 1)
    # detp1 = (invp[:, 0, 0]-1).view(B, 1, 1)
    # detp3 = invp[:, 0, 1].view(B, 1, 1)
    # detp5 = invp[:, 0, 2].view(B, 1, 1)
    # detp2 = invp[:, 1, 0].view(B, 1, 1)
    # detp4 = (invp[:, 1, 1]-1).view(B, 1, 1)
    # detp6 = invp[:, 1, 2].view(B, 1, 1)
    # detp7 = invp[:, 2, 0].view(B, 1, 1)
    # detp8 = invp[:, 2, 1].view(B, 1, 1)
    # den = 1 + p7*detp5 + p8*detp6
    # newp1 = (p1 + detp1 + p1*detp1 + p3*detp2 + p5*detp7 - p7*detp5 - p8*detp6)/den
    # newp2 = (p2 + detp2 + p2*detp1 + p4*detp2 + p6*detp7)/den
    # newp3 = (p3 + detp3 + p1*detp3 + p3*detp4 + p5*detp8) / den
    # newp4 = (p4 + detp4 + p2*detp3 + p4*detp4 + p6*detp8 - p7*detp5 - p8*detp6) / den
    # newp5 = (p5 + detp5 + p1*detp5 + p3*detp6) / den
    # newp6 = (p6 + detp6 + p2*detp5 + p4*detp6) / den
    # newp7 = (p7 + detp7 + p7*detp1 + p8*detp2) / den
    # newp8 = (p8 + detp8 + p7*detp3 + p8*detp4) / den
    # newpose = torch.cat((torch.cat((1+newp1, newp3, newp5), dim=2),
    #                        torch.cat((newp2, 1+newp4, newp6), dim=2),
    #                        torch.cat((newp7, newp8, torch.ones(B, 1, 1).cuda()), dim=2)), dim=1)
    # return newpose

def dwarp_inverse(twist):

    B = twist.size()[0]
    p1 = twist[:, 0, :]
    p2 = twist[:, 1, :]
    p3 = twist[:, 2, :]
    p4 = twist[:, 3, :]
    p5 = twist[:, 4, :]
    p6 = twist[:, 5, :]
    den = (1+p1)*(1+p4)-p2*p3
    newp1 = (-p1 - p1 * p4 + p2 * p3) / den
    newp2 = (-p2) / den
    newp3 = (-p3) / den
    newp4 = (-p4 - p1 * p4 + p2 * p3) / den
    newp5 = (-p5 - p5 * p4 + p3 * p6) / den
    newp6 = (-p6 - p1 * p6 + p2 * p5) / den
    invp = torch.cat((newp1, newp2, newp3, newp4, newp5, newp6), dim=1).view(B, 6, 1)
    return invp

def dwarp_compose(pose, invp):
    B = pose.size()[0]
    p1 = (pose[:, 0, 0]-1).view(B, 1, 1)
    p3 = pose[:, 0, 1].view(B, 1, 1)
    p5 = pose[:, 0, 2].view(B, 1, 1)
    p2 = pose[:, 1, 0].view(B, 1, 1)
    p4 = (pose[:, 1, 1]-1).view(B, 1, 1)
    p6 = pose[:, 1, 2].view(B, 1, 1)
    invp1 = invp[:, 0, 0].view(B, 1, 1)
    invp2 = invp[:, 1, 0].view(B, 1, 1)
    invp3 = invp[:, 2, 0].view(B, 1, 1)
    invp4 = invp[:, 3, 0].view(B, 1, 1)
    invp5 = invp[:, 4, 0].view(B, 1, 1)
    invp6 = invp[:, 5, 0].view(B, 1, 1)
    newp1 = p1+invp1+p1*invp1+p3*invp2
    newp2 = p2+invp2+p2*invp1+p4*invp2
    newp3 = p3+invp3+p1*invp3+p3*invp4
    newp4 = p4+invp4+p2*invp3+p4*invp4
    newp5 = p5+invp5+p1*invp5+p3*invp6
    newp6 = p6+invp6+p2*invp5+p4*invp6
    poseIi = torch.eye(3, dtype=torch.float).expand(B, 3, 3).cuda()
    # poseIi = torch.eye(3, dtype=torch.float).expand(B, 3, 3)
    poseI = poseIi.clone()
    poseI[:, 0, 0] = poseI[:, 0, 0] + newp1.view(B, )
    poseI[:, 1, 0] = poseI[:, 1, 0] + newp2.view(B, )
    poseI[:, 0, 1] = poseI[:, 0, 1] + newp3.view(B, )
    poseI[:, 1, 1] = poseI[:, 1, 1] + newp4.view(B, )
    poseI[:, 0, 2] = poseI[:, 0, 2] + newp5.view(B, )
    poseI[:, 1, 2] = poseI[:, 1, 2] + newp6.view(B, )
    return poseI