import torch
import torch.nn as nn
import torchvision.models as models
import torch.nn.functional as func
import numpy as np
import ICLK.models.geometry as geometry
import torch.nn.functional as F
from ICLK.models.submodules import convLayer as conv
from ICLK.models.submodules import fcLayer, initialize_weights


class TrustRegionBase(nn.Module):
    """
    This is the the base function of the trust-region based inverse compositional algorithm.
    """

    def __init__(self,
                 max_iter=3,
                 mEst_func=None,
                 alpha=None,
                 solver_func=None,
                 timers=None):
        """
        :param max_iter, maximum number of iterations
        :param mEst_func, the M-estimator function / network
        :param alpha用于设置加权数值
        :param solver_func, the trust-region function / network
        :param timers, if yes, counting time for each step
        """
        super(TrustRegionBase, self).__init__()

        self.max_iterations = max_iter
        self.mEstimator = mEst_func
        self.alpha = alpha
        self.directSolver = solver_func
        self.timers = timers

    def forward(self, pose, x0, mask0, x1):
        """
        :param pose, the initial pose
            (extrinsic of the target frame w.r.t. the referenc frame)
        :param x0, the template features
        :param mask0, the mask of the template features
        :param x1, the image features
        :param invD0, the template inverse depth
        :param invD1, the image inverse depth
        :param K, the intrinsic parameters, [fx, fy, cx, cy]
        :param wPrior (optional), provide an initial weight as input to the convolutional m-estimator
        """
        alpha = self.alpha

        B, C, H, W = x0.shape
        # px的大小是(B,1,H,W),其中每个HxW的矩阵的每一行都是[0,1,2,...,W-1]
        # py的大小是(B,1,H,W),其中每个HxW的矩阵的每一列都是[0,1,2,...,H-1]
        px, py = geometry.generate_xy_grid(B, H, W)  # last modify
        # equation (13), J_F_p大小(B,H*W,8)
        J_F_p = self.precompute_Jacobian(x0, px, py)  # precompute_Jacobian for equation(13)

        # 迭代计算公式10，11，12
        for idx in range(self.max_iterations):
            # equation(12)
            residuals = compute_warped_residual(pose, x0, x1, px, py)
            ## 注意：这里面的weights如果是全1才能够预计算wJ，JtWJ
            weights = self.mEstimator(residuals, alpha)  # last modify
            weights = weights*mask0
            # weights.view(B, -1, 1)大小(B,H*W,1)
            # WJ大小(B,H*W,8)
            # 等同于以weights.view(B, -1, 1)对角阵与J_F_p的矩阵积
            wJ = weights.view(B, -1, 1) * J_F_p

            # torch.transpose(J_F_p, 1, 2)的大小是(B,8,H*W),经过torch.bmm得到的
            # JtWJ的大小是(B,8,8)，就是公式(11)括号里面的
            JtWJ = torch.bmm(torch.transpose(J_F_p, 1, 2), wJ)  # last modify
            pose = self.directSolver(JtWJ,
                                     torch.transpose(J_F_p, 1, 2), weights, residuals,
                                     pose, x0, x1)  # last modify but not sure

        return pose

    def precompute_Jacobian(self, x, px, py):
        """ Pre-compute the image Jacobian on the reference frame
        refer to equation (13) in the paper

        :param invD, template depth
        :param x, template feature
        :param px, normalized image coordinate in cols (x)
        :param py, normalized image coordinate in rows (y)
        :param K, the intrinsic parameters, [fx, fy, cx, cy]

        ------------
        :return precomputed image Jacobian on template
        """
        # Jf_x大小与x一致，放置x在水平方向上的差分
        # Jf_y大小与x一致，放置x在垂直方向上的差分
        Jf_x, Jf_y = feature_gradient(x)

        # 对于特征图中的每个点，可以得到一个2x8的Jacobian矩阵
        # Jx_p的大小是(B,H*W,8)，放的是Jacobian矩阵的第一行元素
        # Jy_p的大小是(B,H*W,8)，放的是Jacobian矩阵的第二行元素
        Jx_p, Jy_p = compute_jacobian_warping(x, px, py)

        # J_F_p就是x的梯度与投影变换W(x;p)关于8个参数p的Jacobian矩阵的乘积
        # 大小是(B,H*W,8)
        J_F_p = compute_jacobian_dIdp(Jf_x, Jf_y, Jx_p, Jy_p)
        return J_F_p

class FeaturePyramid(nn.Module):
    """
    The proposed feature-encoder (A).
    It also supports to extract features using one-view only.
    """
    def __init__(self, D):
        super(FeaturePyramid, self).__init__()
        self.net0 = nn.Sequential(
            conv(True, D,  16, 3),
            conv(True, 16, 32, 3, dilation=2),
            conv(True, 32, 32, 3, dilation=2))
        self.net1 = nn.Sequential(
            conv(True, 32, 32, 3),
            conv(True, 32, 64, 3, dilation=2),
            conv(True, 64, 64, 3, dilation=2))
        self.net2 = nn.Sequential(
            conv(True, 64, 64, 3),
            conv(True, 64, 96, 3, dilation=2),
            conv(True, 96, 96, 3, dilation=2))
        self.net3 = nn.Sequential(
            conv(True, 96, 96, 3),
            conv(True, 96, 128, 3, dilation=2),
            conv(True, 128,128, 3, dilation=2))

        initialize_weights(self.net0)
        initialize_weights(self.net1)
        initialize_weights(self.net2)
        initialize_weights(self.net3)
        self.downsample = torch.nn.AvgPool2d(kernel_size=2)

    def forward(self, x):
        x0 = self.net0(x)
        x0s= self.downsample(x0)
        x1 = self.net1(x0s)
        x1s= self.downsample(x1)
        x2 = self.net2(x1s)
        x2s= self.downsample(x2)
        x3 = self.net3(x2s)
        return x0, x1, x2, x3

class DeepRobustEstimator(nn.Module):
    """ The M-estimator

    When use estimator_type = 'MultiScale2w', it is the proposed convolutional M-estimator
    """

    def __init__(self, estimator_type):
        super(DeepRobustEstimator, self).__init__()
        if estimator_type == 'constant':
            ## by Xiaoming
            self.mEst_func = self.__constant_weight
        elif estimator_type == 'huber':
            self.mEst_func = self.__weight_Huber
        else:
            raise NotImplementedError()

        self.net = None

    def forward(self, residual, alpha):
        # 如果选的__constant_weight，w是与residual大小一样的全1张量
        w = self.mEst_func(residual, alpha)
        return w

    def __weight_Huber(self, x, alpha=0.02):
        """ weight function of Huber loss:
        refer to P. 24 w(x) at
        https://members.loria.fr/moberger/Enseignement/Master2/Documents/ZhangIVC-97-01.pdf

        Note this current implementation is not differentiable.
        """
        abs_x = torch.abs(x)
        linear_mask = abs_x > alpha
        w = torch.ones(x.shape).type_as(x)

        if linear_mask.sum().item() > 0:
            w[linear_mask] = alpha / abs_x[linear_mask]
        return w

    def __constant_weight(self, x, alpha=None):
        """ mimic the standard least-square when weighting function is constant
        """
        return torch.ones(x.shape).type_as(x)

class DirectSolverNet(nn.Module):
    def __init__(self, solver_type):
        super(DirectSolverNet, self).__init__()
        self.SOLVER_NO_DAMPING = 0
        if solver_type == 'Direct-Nodamping':
            self.net = None
            self.type = self.SOLVER_NO_DAMPING
        else:
            raise NotImplementedError()

    def forward(self, JtJ, Jt, weights, R, pose0, x0, x1):
        """
        :param JtJ, the approximated Hessian JtJ
        :param Jt, the trasposed Jacobian
        :param weights, the weight matrix
        :param R, the residual
        :param pose0, the initial estimated pose
        :param invD0, the template inverse depth map
        :param invD1, the image inverse depth map
        :param x0, the template feature map
        :param x1, the image feature map
        :param K, the intrinsic parameters

        -----------
        :return updated pose
        """

        B = JtJ.shape[0]
        # 公式(11)中的Wr
        wR = (weights * R).view(B, -1, 1)
        # 公式(11)中的JtWr
        JtR = torch.bmm(Jt, wR)

        if self.type == self.SOLVER_NO_DAMPING:
            # Add a small diagonal damping. Without it, the training becomes quite unstable
            # Do not see a clear difference by removing the damping in inference though
            diag_mask = torch.eye(8).view(1,8,8).type_as(JtJ)
            diagJtJ = diag_mask * JtJ
            traceJtJ = torch.sum(diagJtJ, (2,1))
            # epsilon = (traceJtJ * 1e-6).view(B,1,1) * diag_mask
            # Hessian = JtJ + epsilon
            Hessian = JtJ
            pose_update = inverse_update_pose(Hessian, JtR, pose0)
        else:
            raise NotImplementedError()

        return pose_update

def feature_gradient(img, normalize_gradient=True):
    """ Calculate the gradient on the feature space using Sobel operator
    :param the input image
    -----------
    :return the gradient of the image in x, y direction
    """
    B, C, H, W = img.shape
    # to filter the image equally in each channel
    # wx = torch.FloatTensor([[-1, 0, 1],[-2, 0, 2],[-1, 0, 1]]).view(1,1,3,3).type_as(img)
    # wy = torch.FloatTensor([[-1,-2,-1],[ 0, 0, 0],[ 1, 2, 1]]).view(1,1,3,3).type_as(img)
    wx = torch.FloatTensor([[0, 0, 0], [-0.5, 0, 0.5], [0, 0, 0]]).view(1, 1, 3, 3).type_as(img)
    wy = torch.FloatTensor([[0, -0.5, 0], [ 0, 0, 0], [0, 0.5, 0]]).view(1, 1, 3, 3).type_as(img)
    img_reshaped = img.view(-1, 1, H, W)
    img_pad = func.pad(img_reshaped, (1,1,1,1), mode='replicate')
    img_dx = func.conv2d(img_pad, wx, stride=1, padding=0)
    img_dy = func.conv2d(img_pad, wy, stride=1, padding=0)

    # if normalize_gradient:
    #     mag = torch.sqrt((img_dx ** 2) + (img_dy ** 2)+ 1e-8)
    #     img_dx = img_dx / mag
    #     img_dy = img_dy / mag

    return img_dx.view(B,C,H,W), img_dy.view(B,C,H,W)

# 计算投影变换W(x;p)关于8个参数p的Jacobian矩阵，并取p为0的结果
# 这里面的W(x;p)的定义与Lukas-Kanade 20 years里面的公式(94)的定义一致
def compute_jacobian_warping(p_invdepth, px, py):
    """ Compute the Jacobian matrix of the warped (x,y) w.r.t. the inverse depth
    (linearized at origin)
    :param p_invdepth the input inverse depth
    :param the intrinsic calibration
    :param the pixel x map
    :param the pixel y map
     ------------
    :return the warping jacobian in x, y direction
    """
    B, C, H, W = p_invdepth.size()
    assert(C == 1)

    x = px.view(B, -1, 1)
    y = py.view(B, -1, 1)

    O = torch.zeros((B, H*W, 1)).type_as(p_invdepth)
    FO = torch.ones((B, H*W, 1)).type_as(p_invdepth)
    x2 = torch.mul(x, x)
    y2 = torch.mul(y, y)
    xy = torch.mul(x, y)
    # This is cascaded Jacobian functions of the warping function
    # Refer to the supplementary materials for math documentation
    dx_dp = torch.cat((x, O, y, O, FO, O, -x2, -xy), dim=2)
    dy_dp = torch.cat((O, x, O, y, O, FO, -xy, -y2), dim=2)

    return dx_dp, dy_dp

def compute_jacobian_dIdp(Jf_x, Jf_y, Jx_p, Jy_p):
    """ chained gradient of image w.r.t. the pose
    :param the Jacobian of the feature map in x direction
    :param the Jacobian of the feature map in y direction
    :param the Jacobian of the x map to manifold p
    :param the Jacobian of the y map to manifold p
    ------------
    :return the image jacobian in x, y, direction, Bx2x6 each
    """
    B, C, H, W = Jf_x.shape

    # precompute J_F_p, JtWJ
    Jf_p = Jf_x.view(B, C, -1, 1) * Jx_p.view(B, 1, -1, 8) + \
           Jf_y.view(B, C, -1, 1) * Jy_p.view(B, 1, -1, 8)

    return Jf_p.view(B, -1, 8)

def compute_warped_residual(pose, x0, x1, px, py):
    """ Compute the residual error of warped target image w.r.t. the reference feature map.
    refer to equation (12) in the paper

    :param the forward warping pose from the reference camera to the target frame.
        Note that warping from the target frame to the reference frame is the inverse of this operation.
    :param the reference inverse depth
    :param the target inverse depth
    :param the reference feature image
    :param the target feature image
    :param the pixel x map
    :param the pixel y map
    :param the intrinsic calibration
    -----------
    :return the residual (of reference image), and occlusion information
    """
    u_warped, v_warped = geometry.batch_warp_homo(px, py, pose)
    x1_1to0 = geometry.warp_features(x1, u_warped, v_warped)
    residuals = x1_1to0 - x0
    return residuals


def inverse_update_pose(H, Rhs, pose):
    """ Ues left-multiplication for the pose update
    in the inverse compositional form
    refer to equation (10) in the paper

    :param the (approximated) Hessian matrix
    :param Right-hand side vector
    :param the initial pose (forward transform inverse of xi)
    ---------
    :return the forward updated pose (inverse of xi)
    """
    inv_H = invH(H)
    # xi大小(B,8,1)
    xi = torch.bmm(inv_H, Rhs)
    # inx是对应xi的透射变换
    inx = geometry.Homo_inverse(xi)
    # inv_delpose是inx的逆矩阵
    inv_delpose = invH(inx)
    # new_pose是反向组合的结果,"CLKN: Cascaded Lucas-Kanade Networks for Image Alignment"公式(12)
    new_pose = geometry.Homo_compose(pose, inv_delpose)
    return new_pose

def invH(H):
    """ Generate (H+damp)^{-1}, with predicted damping values
    :param approximate Hessian matrix JtWJ
    -----------
    :return the inverse of Hessian
    """
    # GPU is much slower for matrix inverse when the size is small (compare to CPU)
    # works (50x faster) than inversing the dense matrix in GPU
    if H.is_cuda:
        # invH = bpinv((H).cpu()).cuda()
        # invH = torch.inverse(H)
        invH = torch.inverse(H.cpu()).cuda()
    else:
        invH = torch.inverse(H)
    return invH