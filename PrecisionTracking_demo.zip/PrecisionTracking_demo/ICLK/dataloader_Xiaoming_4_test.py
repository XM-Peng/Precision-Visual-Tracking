from __future__ import absolute_import
from __future__ import division
from __future__ import print_function
from __future__ import unicode_literals

import imageio
import torchvision.transforms as transforms
import numpy as np
import sys, os, random
import pickle
import json
import os.path as osp
import torch.utils.data as data
import cv2

def image_transforms(options):

    transform_list = []

    if 'color_augment' in options:
        augment_parameters = [0.9, 1.1, 0.9, 1.1, 0.9, 1.1]
        transform_list.append(AugmentImages(augment_parameters))

    if 'numpy2torch' in options:
        transform_list.append(ToTensor())

    # if 'color_normalize' in options: # we do it on the fly
    #     transform_list.append(ColorNormalize())

    return transforms.Compose(transform_list)

class ToTensor(object):
    def __init__(self):
        self.transform = transforms.ToTensor()

    def __call__(self, sample):
        return [self.transform(x) for x in sample]

class AugmentImages(object):
    def __init__(self, augment_parameters):
        self.gamma_low  = augment_parameters[0]         # 0.9
        self.gamma_high = augment_parameters[1]         # 1.1
        self.brightness_low  = augment_parameters[2]    # 0.9
        self.brightness_high = augment_parameters[3]    # 1,1
        self.color_low  = augment_parameters[4]         # 0.9
        self.color_high = augment_parameters[5]         # 1.1

        self.thresh = 0.5

    def __call__(self, sample):
        p = np.random.uniform(0, 1, 1)
        if p > self.thresh:
            random_gamma = np.random.uniform(self.gamma_low, self.gamma_high)
            random_brightness = np.random.uniform(self.brightness_low, self.brightness_high)
            random_colors = np.random.uniform(self.color_low, self.color_high, 3)
            for x in sample:
                x = x ** random_gamma             # randomly shift gamma
                x = x * random_brightness         # randomly shift brightness
                for i in range(3):                # randomly shift color
                    x[:, :, i] *= random_colors[i]
                    x[:, :, i] *= random_colors[i]
                x = np.clip(x, a_min=0, a_max=1)  # saturate
            return sample
        else:
            return sample

class JXDT(data.Dataset):
    def __init__(self, train=True,
                 db_root_dir='data',
                 data_transform=None
                 ):
        super(JXDT, self).__init__()
        self.imgname_seq = []
        self.label_seq = []
        self.mask_seq = []
        self.idx = 0

        self.train = train
        self.transforms = data_transform


        if self.train: self.__loadtraindir(db_root_dir)
        else: self.__loadtestdir(db_root_dir)

        print('JX dataloader for training is {:} '.format(self.train))

    def __len__(self):
        return self.idx

    def __loadtraindir(self, root):


        """
            with open('data/groundtruth.txt', 'r') as f:
            p = f.readlines()
            for lines in p:
                lines = lines.strip("\n")
                lines = lines.split(" ")
                es = [[float(lines[0]), float(lines[1]), float(lines[2])], [float(lines[3]), float(lines[4]),
                      float(lines[5])]]
                temname = lines[6]
                imgname = lines[7]
                self.affine_seq.append(es)
                self.temname_seq.append(temname)
                self.imgname_seq.append(imgname)
            self.idx = len(p)
        """

    def __loadtestdir(self, root):
        images = np.sort(os.listdir(root))
        images_path = list(map(lambda x: os.path.join(root, x), images))
        # images_path = map(lambda x: os.path.join('JPEGImages/480p/car-roundabout', x), images)
        self.imgname_seq = images_path
        self.idx = len(self.imgname_seq)

    def __getitem__(self, index):
        """
        Image = cv2.Aff(Template,M)
        Template Warp(M-1) Image
        Image Warp(M) Template
        Template cv2.Aff(M_estimate) Image
        :param index:
        :return:
        """
        imgpath = self.imgname_seq[index]
        img = imageio.imread(imgpath)
        img = img.astype(np.float32) / 255.0
        # img = self.channel_norm(img)

        if self.transforms:
            img = self.transforms([img])
            img = img[0]

        return img, index, imgpath

    def channel_norm(self, img):
        img = np.squeeze(img)
        for i in range(3):
            temp_max = np.max(img[:, :, i])
            img[:, :, i] = img[:, :, i] / (temp_max + 0.000001)
        return img

if __name__ == '__main__':

    loader = JXDT(train=True)
    import torchvision.utils as torch_utils

    torch_loader = data.DataLoader(loader, batch_size=16,
                                   shuffle=False, num_workers=0)

    for batch in torch_loader:
        tem, img, aff, imgpath = batch
        B, C, H, W = tem.shape

        bcolor0_img = torch_utils.make_grid(tem, nrow=4)

        import matplotlib.pyplot as plt

        plt.figure()
        plt.imshow(bcolor0_img.numpy().transpose(1, 2, 0))
        plt.show()