from collections import namedtuple
import importlib
from lib.test.evaluation.data import SequenceList

DatasetInfo = namedtuple('DatasetInfo', ['module', 'class_name', 'kwargs'])

pt = "lib.test.evaluation.%sdataset"  # Useful abbreviations to reduce the clutter
# pt % "otb"将"otb"取代pt中%s的位置

dataset_dict = dict(
    otb=DatasetInfo(module=pt % "otb", class_name="OTBDataset", kwargs=dict()),
    nfs=DatasetInfo(module=pt % "nfs", class_name="NFSDataset", kwargs=dict()),
    uav=DatasetInfo(module=pt % "uav", class_name="UAVDataset", kwargs=dict()),
    tc128=DatasetInfo(module=pt % "tc128", class_name="TC128Dataset", kwargs=dict()),
    tc128ce=DatasetInfo(module=pt % "tc128ce", class_name="TC128CEDataset", kwargs=dict()),
    trackingnet=DatasetInfo(module=pt % "trackingnet", class_name="TrackingNetDataset", kwargs=dict()),
    got10k_test=DatasetInfo(module=pt % "got10k", class_name="GOT10KDataset", kwargs=dict(split='test')),
    got10k_val=DatasetInfo(module=pt % "got10k", class_name="GOT10KDataset", kwargs=dict(split='val')),
    got10k_ltrval=DatasetInfo(module=pt % "got10k", class_name="GOT10KDataset", kwargs=dict(split='ltrval')),
    lasot=DatasetInfo(module=pt % "lasot", class_name="LaSOTDataset", kwargs=dict()),
    lasot_lmdb=DatasetInfo(module=pt % "lasot_lmdb", class_name="LaSOTlmdbDataset", kwargs=dict())
)


def load_dataset(name: str):
    """ Import and load a single dataset."""
    name = name.lower()
    # The get() method returns the value for the specified key if the key is in the dictionary.
    # dset_info包含3个部分，其中，
    # module指定/lib/test/valuation/中要调用的文件，例如got10kdataset.py
    # class_name是一个数据库的名字，例如'GOT10KDataset'
    # kwargs指定字符串的分割符，例如{'split': 'test'}
    dset_info = dataset_dict.get(name)
    if dset_info is None:
        raise ValueError('Unknown dataset \'%s\'' % name)

    m = importlib.import_module(dset_info.module)
    # 由于dset_info.class_name是文件dset_info.module里面的一个类
    # 例如GOT10KDataset是got10kdataset.py的类
    # 所以getattr(m, dset_info.class_name)作用是从got10kdataset.py获取GOT10KDataset
    # 然后通过参数(**dset_info.kwargs)进行初始化
    dataset = getattr(m, dset_info.class_name)(**dset_info.kwargs)  # Call the constructor
    # dataset是一个对象，其主要成员包括：
    # base_path，内含测试数据所在的路径，例如'/media/psdz/Data/Stark/data/got10k/test'
    # sequence_list，每个测试图像序列文件夹的名字列表
    # split，指定是训练、验证集还是其他，例如'test'

    # get_sequence_list()获得数据集中的所有测试序列的信息
    return dataset.get_sequence_list()


def get_dataset(*args):
    """ Get a single or set of datasets."""
    dset = SequenceList()
    for name in args:
        dset.extend(load_dataset(name))
    return dset