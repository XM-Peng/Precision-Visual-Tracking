import numpy as np
from lib.test.evaluation.data import Sequence, BaseDataset, SequenceList
from lib.test.utils.load_text import load_text
import os


class GOT10KDataset(BaseDataset):
    """ GOT-10k dataset.

    Publication:
        GOT-10k: A Large High-Diversity Benchmark for Generic Object Tracking in the Wild
        Lianghua Huang, Xin Zhao, and Kaiqi Huang
        arXiv:1810.11981, 2018
        https://arxiv.org/pdf/1810.11981.pdf

    Download dataset from http://got-10k.aitestunion.com/downloads
    """
    def __init__(self, split):
        super().__init__()
        # Split can be test, val, or ltrval (a validation split consisting of videos from the official train set)
        # self.base_path放置测试数据文件夹的路径
        if split == 'test' or split == 'val':
            self.base_path = os.path.join(self.env_settings.got10k_path, split)
        else:
            self.base_path = os.path.join(self.env_settings.got10k_path, 'train')

        self.sequence_list = self._get_sequence_list(split)
        self.split = split

    def get_sequence_list(self):
        # SequenceList是一个从list继承的类
        # 从其名字看，是放置Sequence类对象的一个list
        return SequenceList([self._construct_sequence(s) for s in self.sequence_list])

    def _construct_sequence(self, sequence_name):
        # sequence_name文件夹里面groundtruth.txt的路径
        anno_path = '{}/{}/groundtruth.txt'.format(self.base_path, sequence_name)
        # load_text函数将groundtruth.txt文件中的bounding box读入ground_truth_rect
        ground_truth_rect = load_text(str(anno_path), delimiter=',', dtype=np.float64)
        # sequence_name文件夹路径
        frames_path = '{}/{}'.format(self.base_path, sequence_name)
        # frame_list是该文件夹中文件的列表
        frame_list = [frame for frame in os.listdir(frames_path) if frame.endswith(".jpg")]
        # 对frame_list是该文件夹中文件的列表进行排序
        frame_list.sort(key=lambda f: int(f[:-4]))
        # 获得这些文件的绝对路径
        frames_list = [os.path.join(frames_path, frame) for frame in frame_list]
        # Sequence是一个类对象，包含一个图像序列的信息
        # 其name成员是本图像序列文件夹名字
        # frames_list成员是本图像序列所包含图像文件的列表
        # dataset成员是测试数据库名字
        # ground_truth_rect成员是本图像序列的ground truth的bbox, 1行4列
        return Sequence(sequence_name, frames_list, 'got10k', ground_truth_rect.reshape(-1, 4))

    def __len__(self):
        return len(self.sequence_list)

    def _get_sequence_list(self, split):
        # 由于self.base_path里面有一个名为list.txt的文件，
        # sequence_list是这个文件的每一行的一个列表
        with open('{}/list.txt'.format(self.base_path)) as f:
            sequence_list = f.read().splitlines()

        if split == 'ltrval':
            with open('{}/got10k_val_split.txt'.format(self.env_settings.dataspec_path)) as f:
                seq_ids = f.read().splitlines()

            sequence_list = [sequence_list[int(x)] for x in seq_ids]
        return sequence_list
