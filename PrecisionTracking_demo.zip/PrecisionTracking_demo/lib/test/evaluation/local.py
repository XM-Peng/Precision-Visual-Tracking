from lib.test.evaluation.environment import EnvSettings

def local_env_settings():
    settings = EnvSettings()

    # Set your local paths here.

    settings.save_dir = '/media/psdz/Data/PrecisionTracking_public/'
    settings.prj_dir = '/media/psdz/Data/PrecisionTracking_public/'

    return settings

