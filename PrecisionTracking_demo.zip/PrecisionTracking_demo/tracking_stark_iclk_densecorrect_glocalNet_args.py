import cv2

import os

import numpy as np
import ICLK.dataloader_Xiaoming_4_test as dataloader
import torch
import torch.nn as nn
import ICLK.models.LeastTracking_Xiaoming
from matplotlib.path import Path


from shapely.geometry import Polygon


import torchvision.transforms as transforms
from models.our_models.GLOCALNet_Xiaoming import GLOCALNet_model
import math

from argparse import ArgumentParser, ArgumentDefaultsHelpFormatter

### stark###
import importlib
from lib.test.tracker.stark_st import STARK_ST


(major_ver, minor_ver, subminor_ver) = (cv2.__version__).split('.')

ix, iy, sx, sy = -1, -1, -1, -1
polygon = []
cross_x, cross_y = -1, -1

def write_np_array_to_txt_file(np_array, txt_file):
    res = np_array.astype(str)
    line_list = []
    for i in range(res.shape[0]):
        line = res[i]
        _str = line[0]
        for j in range(1, res.shape[1]):
            _str = _str + ' ' + line[j]
        line_list.append(_str)

    with open(txt_file, 'w') as f:
        for line in line_list:
            f.write(line)
            f.write('\n')

class TrackingTemplate:
    def __init__(self, width, height,
                 template, mask, target_point,
                 polygon, pose):
        self.width = width  # 模板宽度
        self.height = height  # 模板高度

        if template.nelement() == 0:
            self.template = torch.empty(0)  # 大小为(1, 3, self.height, self.width)
        else:
            self.template = template.clone()

        if mask.nelement() == 0:
            self.mask = torch.empty(0)  # 维数是(1, self.height, self.width)
        else:
            self.mask = mask.clone()

        self.target_point = target_point.copy()  # 浮点，位于模板的坐标,是一个list
        box_center_x = width // 2
        box_center_y = height // 2

        self.bbox_center = (box_center_x, box_center_y)  # 整数坐标，模板的bbox的中心点, 以模板为参考系, 固定值

        self.polygon = polygon.copy()  # 以模板为参考系
        self.pose = pose.copy()  # 3x3 numpy
        # self.first_mask_computed = False
        # self.first_mask_elements = 0

    def get_template(self, img, bbox_center):
        """
        根据模板中心点在当前图像中的位置，截取新模板
        :param img: 从中截取模板的图像，是一个张量
        :param bbox_center: 整数坐标点，以img为参考系
        :return:
        """
        bbox = np.zeros(4, dtype=int)
        bbox[0] = bbox_center[0] - self.bbox_center[0]
        bbox[1] = bbox_center[1] - self.bbox_center[1]
        bbox[2] = self.width
        bbox[3] = self.height
        if bbox[0] >= 0 and bbox[1] >= 0 and bbox[1] + bbox[3] <= img.size()[2] and bbox[0] + bbox[
            2] <= img.size()[3]:
            self.template = img[:, :, bbox[1]:bbox[1] + bbox[3], bbox[0]:bbox[0] + bbox[2]].clone()
        else:
            global tracking_coordinates, fps_list
            tracking_coordinates = np.array(tracking_coordinates)
            fps_array = np.array(fps_list)
            fps_mean = np.mean(fps_array)
            # print("fps_mean=", fps_mean)
            with open(os.path.join(results_dir, 'xy.npy'), 'wb') as f:
                np.save(f, tracking_coordinates)
            write_np_array_to_txt_file(tracking_coordinates, os.path.join(results_dir, "target_point.txt"))
            with open(os.path.join(results_dir, 'fps_mean.npy'), 'wb') as f:
                np.save(f, fps_mean)

            raise Exception("fail to get template")

    def get_mask(self, polygon, bbox_center, width, height):
        """
        本函数调用发生在get_projected_points之后
        :param polygon: 以图像为参考系
        :param bbox_center: 以图像为参考系
        :param width: 图像宽度
        :param height: 图像高度
        :return:
        """
        X, Y = np.meshgrid(np.arange(width), np.arange(height))  # make a canvas with coordinates
        X, Y = X.flatten(), Y.flatten()
        points = np.vstack((X, Y)).T

        p = Path(polygon)  # make a polygon
        grid = p.contains_points(points)
        mask = grid.reshape(height, width)
        mask = mask.astype(np.float32)

        bbox = np.zeros(4, dtype=int)
        bbox[0] = bbox_center[0] - self.bbox_center[0]
        bbox[1] = bbox_center[1] - self.bbox_center[1]
        bbox[2] = self.width
        bbox[3] = self.height
        if bbox[0] >= 0 and bbox[1] >= 0 and bbox[1] + bbox[3] <= img.size()[2] and bbox[0] + bbox[
            2] <= img.size()[3]:
            mask = mask[bbox[1]:bbox[1] + bbox[3], bbox[0]:bbox[0] + bbox[2]]
            self.mask = torch.from_numpy(mask)
            self.mask = torch.unsqueeze(self.mask, 0)  # 维数是(1, self.height, self.width)
            self.mask = torch.unsqueeze(self.mask, 0)  # 维数是(1, 1, self.height, self.width)
            if torch.cuda.is_available():
                self.mask = self.mask.cuda()
        else:
            print("fail to get mask")

    def get_mask_template(self, extra_mask=None):
        """
        从本模板中的polygon生成mask
        :param polygon: 以图像为参考系
        :param bbox_center: 以图像为参考系
        :param width: 图像宽度
        :param height: 图像高度
        :return:
        """
        X, Y = np.meshgrid(np.arange(self.width), np.arange(self.height))  # make a canvas with coordinates
        X, Y = X.flatten(), Y.flatten()
        points = np.vstack((X, Y)).T

        p = Path(self.polygon)  # make a polygon
        grid = p.contains_points(points)
        mask = grid.reshape(self.height, self.width)
        mask = mask.astype(np.float32)

        # num_mask_elements = np.sum(mask)
        # print("num of elements in mask is ", num_mask_elements)

        self.mask = torch.from_numpy(mask)
        self.mask = torch.unsqueeze(self.mask, 0)  # 维数是(1, self.height, self.width)
        self.mask = torch.unsqueeze(self.mask, 0)  # 维数是(1, 1, self.height, self.width)
        if torch.cuda.is_available():
            self.mask = self.mask.cuda()

        if extra_mask is not None:
            self.mask = torch.mul(self.mask, extra_mask)

    def get_num_mask_points(self):  # 获取模板点的个数
        mask = self.mask.cpu().numpy()
        mask = np.squeeze(mask)
        return np.sum(mask)

    def reset_polygon_and_mask(self, extra_mask=None):
        ROI = np.array([0, 0, self.width, self.height]).astype(int)
        polygon = [(ROI[0], ROI[1]), (ROI[2], ROI[1]), (ROI[2], ROI[3]), (ROI[0], ROI[3])]
        self.polygon = polygon.copy()

        mask = np.zeros((self.height, self.width))
        mask[ROI[1]:ROI[3] + 1, ROI[0]:ROI[2] + 1] = 1.
        mask = mask.astype(np.float32)

        self.mask = torch.from_numpy(mask)
        self.mask = torch.unsqueeze(self.mask, 0)  # 维数是(1, self.height, self.width)
        self.mask = torch.unsqueeze(self.mask, 0)  # 维数是(1, 1, self.height, self.width)
        if torch.cuda.is_available():
            self.mask = self.mask.cuda()

        if extra_mask is not None:
            self.mask = torch.mul(self.mask, extra_mask)

    def down_size_pose(self):  # 目的是将其用于金字塔的初始迭代
        self.pose[0, 2] = self.pose[0, 2] / 4.
        self.pose[1, 2] = self.pose[1, 2] / 4.
        self.pose[2, 0] = self.pose[2, 0] * 4.
        self.pose[2, 1] = self.pose[2, 1] * 4.

    def get_newpose_translation(self, new_bbox_center):
        """
        从模板在当前图像的中心点位置获得新的姿态
        :param new_bbox_center: 模板在当前图像的中心点位置
        :return:
        """
        new_pose = np.eye(3, dtype=np.float32)
        new_pose[0, 2] = new_bbox_center[0] - self.bbox_center[0]
        new_pose[1, 2] = new_bbox_center[1] - self.bbox_center[1]
        self.pose = new_pose.copy()

    def get_projected_points(self, newpose, width, height):
        """
        使用newpose求模板中的polygon、bbox_center和target_point在图像中的投影
        pose is 3x3 numpy
        """
        polygon = self.polygon
        num_points = len(polygon) + 2
        E = np.zeros((3, num_points))
        E[2, :] = np.ones(num_points)
        for i in range(len(polygon)):
            E[0, i] = polygon[i][0]
            E[1, i] = polygon[i][1]

        E[0, num_points - 2] = self.bbox_center[0]
        E[1, num_points - 2] = self.bbox_center[1]
        E[0, num_points - 1] = self.target_point[0]
        E[1, num_points - 1] = self.target_point[1]

        projected_E = np.matmul(newpose, E)
        projected_E = projected_E / projected_E[2, :]

        new_target_x, new_target_y = \
            projected_E[0, num_points - 1].astype(np.float32), projected_E[1, num_points - 1].astype(np.float32)

        projected_E = projected_E.round().astype(int)

        new_polygon_outside_img = False
        new_polygon = []
        for i in range(len(polygon)):
            new_polygon.append((projected_E[0, i], projected_E[1, i]))
            if projected_E[0, i] < 0 or projected_E[0, i] > width - 1 or projected_E[1, i] < 0 or projected_E[
                1, i] > height - 1:
                new_polygon_outside_img = True

        new_box_center_x, new_box_center_y = \
            projected_E[0, num_points - 2], projected_E[1, num_points - 2]
        return new_polygon, new_polygon_outside_img, (new_box_center_x, new_box_center_y), (new_target_x, new_target_y)

    def shift_to_template(self, new_polygon, new_bbox_center, new_target_point):
        """
        将get_projected_points得到的new_polygon和new_target_point转化为模板参考系
        :param new_polygon: 以图像为参考系
        :param new_bbox_center: 以图像为参考系
        :param new_target_point: 以图像为参考系
        :return:
        """

        shift = (self.bbox_center[0] - new_bbox_center[0],
                 self.bbox_center[1] - new_bbox_center[1])
        ## 生成自己的polygon
        polygon = []
        for i in range(len(new_polygon)):
            polygon.append((new_polygon[i][0] + shift[0].astype(int), new_polygon[i][1] + shift[1].astype(int)))

        template_polygon = Polygon(
            [(0, 0), (self.width - 1, 0), (self.width - 1, self.height - 1), (0, self.height - 1)])
        try:
            intersect = template_polygon.intersection(Polygon(polygon))
        except:
            return False  # raise Exception("The polygon is abnormal")

        if intersect.area > 10.:
            try:
                x, y = intersect.exterior.coords.xy
            except:
                return False
            polygon2 = []
            for i in range(len(x)):
                polygon2.append((int(x[i]), int(y[i])))
            polygon2 = polygon2[0:len(polygon2) - 1]
            self.polygon = polygon2.copy()
        else:
            return False

        self.target_point[0] = new_target_point[0] + shift[0]
        self.target_point[1] = new_target_point[1] + shift[1]

        self.target_point[0] = self.target_point[0].astype(np.float32)
        self.target_point[1] = self.target_point[1].astype(np.float32)

        return True

    def bbox_overlapping_with_global(self, bbox_center, global_bbox):
        """
        得到精跟踪框与粗跟踪框的交集
        输入：
            bbox_center - 精跟踪框中心在图像中的坐标位置
            global_bbox - 粗跟踪框
        """
        if global_bbox is None:
            return None

        bbox = np.zeros(4, dtype=int)  # 精跟踪框在图像中的位置
        bbox[0] = bbox_center[0] - self.bbox_center[0]
        bbox[1] = bbox_center[1] - self.bbox_center[1]
        bbox[2] = self.width
        bbox[3] = self.height

        global_bbox_copy = global_bbox.copy()

        global_bbox_copy[0] -= bbox[0]
        global_bbox_copy[1] -= bbox[1]

        template_polygon = Polygon(
            [(0, 0), (self.width - 1, 0), (self.width - 1, self.height - 1), (0, self.height - 1)])
        global_polygon = Polygon(
            [(global_bbox_copy[0], global_bbox_copy[1]),
             (global_bbox_copy[0] + global_bbox_copy[2] - 1, global_bbox_copy[1]),
             (global_bbox_copy[0] + global_bbox_copy[2] - 1, global_bbox_copy[1] + global_bbox_copy[3] - 1),
             (global_bbox_copy[0], global_bbox_copy[1] + global_bbox_copy[3] - 1)])
        intersect = template_polygon.intersection(global_polygon)

        min_x, min_y, max_x, max_y = self.width, self.height, -1, -1

        if intersect.area > 10.:
            x, y = intersect.exterior.coords.xy
            for i in range(len(x)):
                min_x = min(min_x, x[i])
                max_x = max(max_x, x[i])

                min_y = min(min_y, y[i])
                max_y = max(max_y, y[i])

            min_x = int(min_x)
            min_y = int(min_y)
            max_x = int(max_x)
            max_y = int(max_y)

            mask = np.zeros((self.height, self.width))
            mask[min_y:max_y + 1, min_x:max_x + 1] = 1.
            mask = mask.astype(np.float32)

            mask = torch.from_numpy(mask)
            mask = torch.unsqueeze(mask, 0)  # 维数是(1, self.height, self.width)
            mask = torch.unsqueeze(mask, 0)  # 维数是(1, 1, self.height, self.width)
            if torch.cuda.is_available():
                mask = mask.cuda()
            return mask
        else:
            return None

    def generate_new_template(self, newpose, img, global_bbox=None, allow_adjust_template_sz=False):
        """
        生成新模板
        :param newpose: 模板在图像中的姿态
        :param img: 当前图像
        :return:
        """
        width, height = img.size()[3], img.size()[2]
        new_polygon, new_polygon_outside_img, new_bbox_center, new_target_point = \
            self.get_projected_points(newpose, width, height)
        template_sz_changed = False
        new_template = None
        if not allow_adjust_template_sz:
            new_template = TrackingTemplate(self.width, self.height,
                                            torch.empty(0), torch.empty(0),
                                            [-1., -1.], self.polygon, newpose)
        else:
            if 1. * self.width / global_bbox[2] < 0.8 or 1. * self.height / global_bbox[3] < 0.8:
                template_sz_changed = True
                # increase template size
                new_w, new_h = \
                    max(0.8 * global_bbox[2], self.width), \
                    max(0.8 * global_bbox[3], self.height)
                new_w = int(np.ceil(new_w / 8.0) * 8)
                new_h = int(np.ceil(new_h / 8.0) * 8)

                new_template = TrackingTemplate(new_w, new_h,
                                                torch.empty(0), torch.empty(0),
                                                [-1., -1.], self.polygon, newpose)
            elif 1. * self.width / global_bbox[2] > 1.2 or 1. * self.height / global_bbox[3] > 1.2:
                # decrease template size
                template_sz_changed = True
                new_w, new_h = \
                    min(global_bbox[2], self.width), \
                    min(global_bbox[3], self.height)
                new_w = int(np.ceil(new_w / 8.0) * 8)
                new_h = int(np.ceil(new_h / 8.0) * 8)

                new_template = TrackingTemplate(new_w, new_h,
                                                torch.empty(0), torch.empty(0),
                                                [-1., -1.], self.polygon, newpose)

        if not template_sz_changed:
            new_template = TrackingTemplate(self.width, self.height,
                                            torch.empty(0), torch.empty(0),
                                            [-1., -1.], self.polygon, newpose)
        extra_mask = new_template.bbox_overlapping_with_global(new_bbox_center, global_bbox)
        # 更新new_template的template
        new_template.get_template(img, new_bbox_center)

        if not allow_adjust_template_sz or not template_sz_changed:
            # 更新new_template的polygon和target_point
            if not new_template.shift_to_template(new_polygon, new_bbox_center, new_target_point):
                return None, None

            new_template.get_mask_template(extra_mask)
            num_new_mask = new_template.get_num_mask_points()
            # print("num of elements in mask is ", num_new_mask)
            if num_new_mask < 0.75 * self.get_num_mask_points() and num_new_mask < 0.25 * self.width * self.height:
                new_template.reset_polygon_and_mask(extra_mask)
                num_new_mask = new_template.get_num_mask_points()
                if num_new_mask < 0.25 * self.width * self.height:
                    return None, None
        elif template_sz_changed:
            # 更新new_template的polygon和target_point
            new_template.reset_polygon_and_mask(extra_mask)
            # num_new_mask = new_template.get_num_mask_points()
            # print("num of elements in mask is ", num_new_mask)
            shift = (new_template.bbox_center[0] - new_bbox_center[0],
                     new_template.bbox_center[1] - new_bbox_center[1])
            new_template.target_point[0] = new_target_point[0] + shift[0]
            new_template.target_point[1] = new_target_point[1] + shift[1]

            new_template.target_point[0] = new_template.target_point[0].astype(np.float32)
            new_template.target_point[1] = new_template.target_point[1].astype(np.float32)

        # 更新new_template的pose
        new_template.get_newpose_translation(new_bbox_center)

        # new_template的pose进行参数校正，用于金字塔迭代
        new_template.down_size_pose()

        return new_template, template_sz_changed

    def reinitialize_template(self, new_target_point, img, global_bbox=None):
        """
        生成新模板
        :param newpose: 模板在图像中的姿态
        :param img: 当前图像
        :return:
        """
        width, height = img.size()[3], img.size()[2]
        new_template = TrackingTemplate(self.width, self.height,
                                        torch.empty(0), torch.empty(0),
                                        [-1., -1.], self.polygon, self.pose)

        new_bbox_center = [int(new_target_point[0]), int(new_target_point[1])]
        extra_mask = new_template.bbox_overlapping_with_global(new_bbox_center, global_bbox)
        # 更新new_template的template
        new_template.get_template(img, new_bbox_center)
        new_template.reset_polygon_and_mask(extra_mask)
        num_new_mask = new_template.get_num_mask_points()
        shift = (new_template.bbox_center[0] - new_bbox_center[0],
                 new_template.bbox_center[1] - new_bbox_center[1])
        new_template.target_point[0] = new_target_point[0] + shift[0]
        new_template.target_point[1] = new_target_point[1] + shift[1]

        new_template.target_point[0] = new_template.target_point[0].astype(np.float32)
        new_template.target_point[1] = new_template.target_point[1].astype(np.float32)

        # 更新new_template的pose
        new_template.get_newpose_translation(new_bbox_center)

        # new_template的pose进行参数校正，用于金字塔迭代
        new_template.down_size_pose()

        return new_template


def generate_tracking_batch_1_template(tracking_template_0: TrackingTemplate, img):
    templates = tracking_template_0.template
    masks = tracking_template_0.mask
    imgs = img.clone()
    intpose = np.expand_dims(tracking_template_0.pose, axis=0)
    intpose = torch.from_numpy(intpose)
    if torch.cuda.is_available():
        intpose = intpose.cuda()
    return templates, masks, imgs, intpose


def generate_tracking_batch_2_templates(tracking_template_0: TrackingTemplate,
                                        tracking_template_1: TrackingTemplate,
                                        img):
    templates = torch.cat((tracking_template_0.template, tracking_template_1.template), dim=0)
    masks = torch.cat((tracking_template_0.mask, tracking_template_1.mask), dim=0)
    imgs = torch.cat((img.clone(), img.clone()), dim=0)
    pose0 = np.expand_dims(tracking_template_0.pose, axis=0)
    pose1 = np.expand_dims(tracking_template_1.pose, axis=0)
    intpose = np.concatenate((pose0, pose1), axis=0)
    intpose = torch.from_numpy(intpose)
    if torch.cuda.is_available():
        intpose = intpose.cuda()
    return templates, masks, imgs, intpose


def get_tracking_box(new_bbox_center, w, h):
    tracking_box = np.zeros(4, dtype=int)
    box_center_x = w // 2
    box_center_y = h // 2
    tracking_box[0] = new_bbox_center[0] - box_center_x
    tracking_box[1] = new_bbox_center[1] - box_center_y
    tracking_box[2] = w
    tracking_box[3] = h
    return tracking_box


def from_polygon_to_bbox(polygon, bbox):
    global cross_x, cross_y
    """
    按照手工选定的多边形设置精跟踪bbox
    Input:
        polygon - 手工选定的多边形
        bbox - 粗跟踪bbox
    Output:
        new_polygon - 精跟踪多边形，以模板作为参考坐标系
        new_bbox - 精跟踪bbox，相对于图像坐标系
    """
    min_x, min_y, max_x, max_y = 1e6, 1e6, -1, -1
    for i in range(len(polygon)):
        x = polygon[i][0]
        y = polygon[i][1]
        min_x = min(min_x, x)
        max_x = max(max_x, x)

        min_y = min(min_y, y)
        max_y = max(max_y, y)

    w = max_x - min_x + 1
    h = max_y - min_y + 1
    new_w = int(np.ceil(w / 8.0) * 8)
    new_h = int(np.ceil(h / 8.0) * 8)

    new_polygon = []
    new_bbox = [bbox[0] + min_x, bbox[1] + min_y, new_w, new_h]  # 精跟踪bbox，相对于图像坐标系
    shift_x, shift_y = min_x, min_y

    for i in range(len(polygon)):
        x = polygon[i][0]
        y = polygon[i][1]
        new_polygon.append((x - shift_x, y - shift_y))

    cross_x -= shift_x
    cross_y -= shift_y
    return new_polygon, new_bbox


def read_image(image_file: str):
    im = cv2.imread(image_file)
    return cv2.cvtColor(im, cv2.COLOR_BGR2RGB)

def check_cuda(items):
    if torch.cuda.is_available():
        return [x.cuda() for x in items]
    else:
        return items

if __name__ == '__main__':
    # Parse command line arguments
    parser = ArgumentParser(formatter_class=ArgumentDefaultsHelpFormatter)
    parser.add_argument("-path", "--sequence_path", default=" ", type=str, help="The folder of the image sequence")
    parser.add_argument("-x", "--cross_x", default=-1, type=int, help="The x coordinate of the tracking point")
    parser.add_argument("-y", "--cross_y", default=-1, type=int, help="The y coordinate of the tracking point")
    parser.add_argument("-tlx", "--top_left_x", default=-1, type=int, help="The x coordinate of the top-left corner of the bbox")
    parser.add_argument("-tly", "--top_left_y", default=-1, type=int, help="The y coordinate of the top-left corner of the bbox")
    parser.add_argument("-bw", "--box_w", default=96, type=int, help="The width of the box")
    parser.add_argument("-bh", "--box_h", default=96, type=int, help="The height of the box")

    args = parser.parse_args()

    image_sequence_path = os.path.join(args.sequence_path, 'images') # '/media/psdz/Data/monkaa_frames_cleanpass_jpg/a_rain_of_stones_x2/left'
    cross_x, cross_y = args.cross_x, args.cross_y
    TL_x, TL_y = args.top_left_x, args.top_left_y
    w, h = args.box_w, args.box_h

    datatransform = dataloader.image_transforms(['numpy2torch'])
    dataset = dataloader.JXDT(train=False, db_root_dir=image_sequence_path,
                              data_transform=datatransform)  # need to modify
    loader = torch.utils.data.DataLoader(dataset=dataset, batch_size=1,
                                         shuffle=False, num_workers=0)

    ## set parameters
    allow_adjust_template_sz = True  # 是否允许跟踪过程中调整模板大小
    allow_indepedent_tracking = False  # 模板匹配跟踪是否单独进行（即不依赖于目标整体跟踪）
    allow_densematchig_correct = True  # 是否允许基于dense correspondence的漂移校正
    allow_reinitialize_template = True  # 在跟踪过程中出现计算错误时是否允许重设模板

    tracking_coordinates = []
    fps_list = []
    results_dir = os.path.join(args.sequence_path, 'results')
    if not os.path.exists(results_dir):
        os.makedirs(results_dir)

    if allow_indepedent_tracking:
        allow_adjust_template_sz = False

    ###DenseMatching###
    mean_vector = np.array([0.485, 0.456, 0.406])
    std_vector = np.array([0.229, 0.224, 0.225])
    normTransform = transforms.Normalize(mean_vector, std_vector)
    image_transforms = transforms.Compose([transforms.ToTensor(),
                                           normTransform])
    # models
    dense_matching_model = GLOCALNet_model(batch_norm=True, pyramid_type='VGG', div=1., evaluation=True,
                                           refinement=True, residual=True,
                                           input_decoder='flow_and_feat', refinement_32=False)
    dense_matching_model_checkpoint = \
        torch.load('./pretrained/model_best.pth')
    dense_matching_model.load_state_dict(dense_matching_model_checkpoint['state_dict'])
    dense_matching_model = nn.DataParallel(dense_matching_model)
    if torch.cuda.is_available():
        dense_matching_model = dense_matching_model.cuda()
    dense_matching_model.eval()

    bbox_64 = np.zeros(4, dtype=int)
    bbox_64[2], bbox_64[3] = 64, 64
    bbox_64[0], bbox_64[1] = int(cross_x - 32), int(cross_y - 32)

    ###ICLK###
    ic_net = ICLK.models.LeastTracking_Xiaoming.LeastSquareTracking(max_iter_per_pyr=5,
                                                                    mEst_type='constant',
                                                                    alpha=[None, None, None, None],
                                                                    solver_type='Direct-Nodamping',
                                                                    timers=None)

    """load weights"""
    ic_weights_path = './pretrained/pretrained_iclk_Xiaoming.pth'
    ic_weights_dict = torch.load(ic_weights_path, map_location='cpu')
    ic_net.load_state_dict(ic_weights_dict)

    if torch.cuda.is_available():
        ic_net.cuda()
    ic_net.eval()

    ###STARK###
    if not allow_indepedent_tracking:
        tracker_param_module = importlib.import_module('lib.test.parameter.stark_st')
        tracker_params = tracker_param_module.parameters('baseline_R101')
        tracker_params.cfg.DATA.MAX_SAMPLE_INTERVAL = [20]
        tracker = STARK_ST(tracker_params, "")
    else:
        tracker = None

    # Read first frame.
    frame_ind = 0
    frame = cv2.imread(dataset.imgname_seq[0], cv2.IMREAD_UNCHANGED)
    frame_w, frame_h = frame.shape[1], frame.shape[0]

    # bounding box
    bbox = np.zeros(4, dtype=int)
    box_center_x = w // 2
    box_center_y = h // 2
    bbox[0] = TL_x # cross_x - box_center_x
    bbox[1] = TL_y # cross_y - box_center_y
    bbox[2] = w
    bbox[3] = h

    bbox = list(bbox)

    init_info = {'init_bbox': [bbox[0], bbox[1], bbox[2], bbox[3]]}
    tracking_coordinates.append([1. * cross_x, 1. * cross_y])

    """
    immportant!!!
    """
    cross_x, cross_y = cross_x-TL_x, cross_y-TL_y # box_center_x, box_center_y


    try:
        reference_template = frame[bbox_64[1]:bbox_64[1] + bbox_64[3],
                             bbox_64[0]:bbox_64[0] + bbox_64[2], :].copy()
        reference_template = np.stack(
            (reference_template[:, :, 2], reference_template[:, :, 1], reference_template[:, :, 0]), axis=2)  # RGB
        reference_template = image_transforms(reference_template)
    except:
        tracking_coordinates = np.array(tracking_coordinates)
        fps_array = np.array(fps_list)
        fps_mean = np.mean(fps_array)
        # print("fps_mean=", fps_mean)
        with open(os.path.join(results_dir, 'xy.npy'), 'wb') as f:
            np.save(f, tracking_coordinates)
        write_np_array_to_txt_file(tracking_coordinates, os.path.join(results_dir, "target_point.txt"))
        with open(os.path.join(results_dir, 'fps_mean.npy'), 'wb') as f:
            np.save(f, fps_mean)

        raise Exception("The reference template is too close to the image border.")

    TH = 2.

    polygon_dummy = [(None, None)]
    pose_dummy = np.eye(3, dtype=np.float32)

    tracking_template_0 = TrackingTemplate(w, h, torch.empty(0), torch.empty(0),
                                           [-1., -1.], polygon_dummy, pose_dummy)
    tracking_template_1 = TrackingTemplate(w, h, torch.empty(0), torch.empty(0),
                                           [-1., -1.], polygon_dummy, pose_dummy)

    tracking_box = np.zeros(4, dtype=int)
    tracking_cross_x, tracking_cross_y = -1, -1
    template_updated = 0
    num_template_sz_changed = 0
    drift_corrected = 0

    # clean results_dir folder
    is_results_dir_exist = os.path.exists(results_dir)
    if not is_results_dir_exist:
        os.mkdir(results_dir)
    else:
        for f in os.listdir(results_dir):
            os.remove(os.path.join(results_dir, f))

    if len(polygon) == 0:
        polygon = [(0, 0), (w - 1, 0), (w - 1, h - 1), (0, h - 1)]

    # 删除polygon里面的重复点
    polygon = list(dict.fromkeys(polygon))
    # 设置精跟踪框
    polygon, bbox = from_polygon_to_bbox(polygon, bbox)
    # 重设w，h
    w, h = bbox[2], bbox[3]

    densematchig_corrected = True
    # 开始跟踪

    with torch.no_grad():
        for batch_idx, batch in enumerate(loader):
            if batch_idx >= 1:
                # Start timer
                timer = cv2.getTickCount()

            current_frame = cv2.imread(dataset.imgname_seq[batch_idx], cv2.IMREAD_UNCHANGED)
            ###STARK###
            if not allow_indepedent_tracking:
                image_stark = read_image(dataset.imgname_seq[batch_idx])
            else:
                image_stark = None

            ###ICLK###
            img, index = batch[0:2]
            img = check_cuda([img])
            img = img[0]
            img_width = img.shape[3]
            img_height = img.shape[2]

            if batch_idx == 0:  # 准备第一个模板
                ###STARK###
                # 一般来说out是None, 但是initialize()设置了tracker的
                # z_dict_list成员,其内容是初始模板送入网络后的输出;由于一开始没有动态模板，所以其位置由初始模板承担
                # state成员，即初始的bbox
                # frame_id成员，即当前处理帧号
                if not allow_indepedent_tracking:
                    out = tracker.initialize(image_stark, init_info)

                ###ICLK###
                pose0 = np.array([[1., 0., bbox[0]], [0., 1., bbox[1]], [0., 0., 1.]], dtype=np.float32)
                del tracking_template_0
                tracking_template_0 = TrackingTemplate(w, h, torch.empty(0), torch.empty(0),
                                                       [1. * cross_x, 1. * cross_y], polygon, pose0)
                new_polygon, new_polygon_outside_img, new_bbox_center, new_target_point = \
                    tracking_template_0.get_projected_points(pose0, img_width, img_height)
                # 更新tracking_template_0的template
                tracking_template_0.get_template(img, new_bbox_center)
                # 更新tracking_template_0的mask
                tracking_template_0.get_mask(new_polygon, new_bbox_center, img_width, img_height)
                # tracking_template_0的pose进行参数校正，用于金字塔迭代
                tracking_template_0.down_size_pose()
            elif batch_idx == 1:  # 用第一个模板进行跟踪
                ###STARK###
                # out字典主要包括target_bbox和conf_score两个key
                # 前者是在当前帧得到的bbox，后者是检测到目标的确信度
                if not allow_indepedent_tracking:
                    out = tracker.track(image_stark, None)
                    global_bbox = out['target_bbox']
                    global_bbox = [int(c) for c in global_bbox]
                else:
                    global_bbox = None

                ###ICLK###
                templates, masks, imgs, intpose = \
                    generate_tracking_batch_1_template(tracking_template_0, img)
                estpose = ic_net.forward(templates, masks, imgs, intpose)
                estpose = estpose.cpu().numpy()
                estpose = np.squeeze(estpose)

                new_polygon_0, new_polygon_outside_img_0, new_bbox_center_0, new_target_point_0 = \
                    tracking_template_0.get_projected_points(estpose, img_width, img_height)
                # print(estpose)
                # 准备第二个模板
                del tracking_template_1
                if not allow_indepedent_tracking:
                    tracking_template_1, _ = tracking_template_0.generate_new_template(estpose, img,
                                                                                       global_bbox=global_bbox)
                else:
                    tracking_template_1, _ = tracking_template_0.generate_new_template(estpose, img)
                # tracking_template_1 = tracking_template_0.generate_new_template(estpose, img)
                # 对第一个模板下进行参数校正，为下一次跟踪准备
                tracking_template_0.pose = estpose.copy()
                tracking_template_0.down_size_pose()
                if tracking_template_1.template.nelement() == 0 or tracking_template_1.mask.nelement() == 0:
                    break

                # 跟踪框
                tracking_box = get_tracking_box(new_bbox_center_0, w, h)
                # tracking_cross_x, tracking_cross_y = int(new_target_point_0[0]), int(new_target_point_0[1])
                tracking_cross_x, tracking_cross_y = new_target_point_0[0], new_target_point_0[1]
            else:  # 双模板同时跟踪
                ###STARK###
                # out字典主要包括target_bbox和conf_score两个key
                # 前者是在当前帧得到的bbox，后者是检测到目标的确信度
                if not allow_indepedent_tracking:
                    out = tracker.track(image_stark, None)
                    global_bbox = out['target_bbox']
                    global_bbox = [int(c) for c in global_bbox]
                else:
                    global_bbox = None

                ###ICLK###
                templates, masks, imgs, intpose = \
                    generate_tracking_batch_2_templates(tracking_template_0, tracking_template_1, img)
                estpose = ic_net.forward(templates, masks, imgs, intpose)
                estpose = estpose.cpu().numpy()

                # 模板0的跟踪情况
                estpose_0 = estpose[0, :, :]
                new_polygon_0, new_polygon_outside_img_0, new_bbox_center_0, new_target_point_0 = \
                    tracking_template_0.get_projected_points(estpose_0, img_width, img_height)

                # 模板1的跟踪情况
                estpose_1 = estpose[1, :, :]
                new_polygon_1, new_polygon_outside_img_1, new_bbox_center_1, new_target_point_1 = \
                    tracking_template_1.get_projected_points(estpose_1, img_width, img_height)

                distance2 = (new_target_point_0[0] - new_target_point_1[0]) * \
                            (new_target_point_0[0] - new_target_point_1[0]) + \
                            (new_target_point_0[1] - new_target_point_1[1]) * \
                            (new_target_point_0[1] - new_target_point_1[1])

                if np.sqrt(distance2) < TH:
                    # 更新第二个模板
                    # print("keep template 0, update template 1")
                    # print(distance2)
                    del tracking_template_1
                    update_template_0_pose = True
                    if not allow_indepedent_tracking:
                        tracking_template_1, _ = tracking_template_0.generate_new_template(estpose_0, img,
                                                                                           global_bbox=global_bbox)
                        if tracking_template_1 is None:
                            tracking_template_1 = \
                                tracking_template_0.reinitialize_template(new_target_point_0, img,
                                                                          global_bbox=global_bbox)
                            # 重新设置模板0
                            tracking_template_0.width = tracking_template_1.width
                            tracking_template_0.height = tracking_template_1.height
                            tracking_template_0.template = tracking_template_1.template.clone()
                            tracking_template_0.mask = tracking_template_1.mask.clone()
                            tracking_template_0.target_point = tracking_template_1.target_point.copy()
                            tracking_template_0.polygon = tracking_template_1.polygon.copy()  # 以模板为参考系
                            tracking_template_0.pose = tracking_template_1.pose.copy()
                            tracking_template_0.bbox_center = (
                                tracking_template_1.bbox_center[0], tracking_template_1.bbox_center[1])

                            update_template_0_pose = False
                    else:
                        tracking_template_1, _ = tracking_template_0.generate_new_template(estpose_0, img)
                        if tracking_template_1 is None:
                            tracking_template_1 = \
                                tracking_template_0.reinitialize_template(new_target_point_0, img)
                            # 重新设置模板0
                            tracking_template_0.width = tracking_template_1.width
                            tracking_template_0.height = tracking_template_1.height
                            tracking_template_0.template = tracking_template_1.template.clone()
                            tracking_template_0.mask = tracking_template_1.mask.clone()
                            tracking_template_0.target_point = tracking_template_1.target_point.copy()
                            tracking_template_0.polygon = tracking_template_1.polygon.copy()  # 以模板为参考系
                            tracking_template_0.pose = tracking_template_1.pose.copy()
                            tracking_template_0.bbox_center = (
                                tracking_template_1.bbox_center[0], tracking_template_1.bbox_center[1])

                            update_template_0_pose = False

                    # tracking_template_1 = tracking_template_0.generate_new_template(estpose_0, img)
                    # 对第一个模板进行参数校正，为下一次跟踪准备
                    if update_template_0_pose:
                        tracking_template_0.pose = estpose_0.copy()
                        tracking_template_0.down_size_pose()

                    if tracking_template_1.template.nelement() == 0 or tracking_template_1.mask.nelement() == 0:
                        break

                    # 跟踪框
                    tracking_box = get_tracking_box(new_bbox_center_0, w, h)
                    # tracking_cross_x, tracking_cross_y = int(new_target_point_0[0]), int(new_target_point_0[1])
                    tracking_cross_x, tracking_cross_y = new_target_point_0[0], new_target_point_0[1]
                else:
                    # 淘汰第一个模板，其位置被第二个模板取代
                    tracking_template_0.template = tracking_template_1.template.clone()
                    tracking_template_0.mask = tracking_template_1.mask.clone()
                    tracking_template_0.target_point = tracking_template_1.target_point.copy()
                    tracking_template_0.polygon = tracking_template_1.polygon.copy()  # 以模板为参考系
                    tracking_template_0.pose = estpose_1.copy()
                    tracking_template_0.down_size_pose()
                    # 同时，用其生成第二个模板
                    # print("Remove template 0, update template 1")
                    del tracking_template_1
                    if not allow_indepedent_tracking:
                        tracking_template_1, template_sz_changed = \
                            tracking_template_0.generate_new_template(estpose_1, img,
                                                                      global_bbox=global_bbox,
                                                                      allow_adjust_template_sz=allow_adjust_template_sz)
                        if tracking_template_1 is None:
                            tracking_template_1 = \
                                tracking_template_0.reinitialize_template(new_target_point_1, img,
                                                                          global_bbox=global_bbox)

                    else:
                        tracking_template_1, template_sz_changed = \
                            tracking_template_0.generate_new_template(estpose_1, img,
                                                                      global_bbox=None,
                                                                      allow_adjust_template_sz=allow_adjust_template_sz)
                        if tracking_template_1 is None:
                            tracking_template_1 = \
                                tracking_template_0.reinitialize_template(new_target_point_1, img)

                    # reset tracking_template_0
                    tracking_template_0.width = tracking_template_1.width
                    tracking_template_0.height = tracking_template_1.height
                    tracking_template_0.template = tracking_template_1.template.clone()
                    tracking_template_0.mask = tracking_template_1.mask.clone()
                    tracking_template_0.target_point = tracking_template_1.target_point.copy()
                    tracking_template_0.polygon = tracking_template_1.polygon.copy()  # 以模板为参考系
                    tracking_template_0.pose = tracking_template_1.pose.copy()
                    tracking_template_0.bbox_center = (
                        tracking_template_1.bbox_center[0], tracking_template_1.bbox_center[1])
                    if (template_sz_changed is not None) and template_sz_changed:
                        # 重设w，h
                        w, h = tracking_template_0.width, tracking_template_0.height
                        num_template_sz_changed += 1

                    if tracking_template_1.template.nelement() == 0 or tracking_template_1.mask.nelement() == 0:
                        break

                    # 跟踪框
                    tracking_box = get_tracking_box(new_bbox_center_1, w, h)

                    tracking_cross_x, tracking_cross_y = new_target_point_1[0], new_target_point_1[1]
                    template_updated += 1
                    densematchig_corrected = False

                ##尝试漂移矫正
                if allow_densematchig_correct and batch_idx % 5 == 0 and template_updated > 0 and (
                not densematchig_corrected):
                    tracking_cross_x_old, tracking_cross_y_old = tracking_cross_x, tracking_cross_y
                    tracking_cross_x_int, tracking_cross_y_int = \
                        int(tracking_cross_x), int(tracking_cross_y)

                    try:
                        query_template = \
                            current_frame[int(tracking_cross_y_int - 32):int(tracking_cross_y_int + 32),
                            int(tracking_cross_x_int - 32):int(tracking_cross_x_int + 32)].copy()
                        query_template = np.stack(
                            (query_template[:, :, 2], query_template[:, :, 1], query_template[:, :, 0]),
                            axis=2)  # RGB
                        query_template = image_transforms(query_template)
                        flow = dense_matching_model(
                            torch.cat((reference_template.unsqueeze(0), query_template.unsqueeze(0)), dim=0).cuda(),
                            torch.cat((query_template.unsqueeze(0), reference_template.unsqueeze(0)),
                                      dim=0).cuda()).cpu().numpy()
                    except:
                        tracking_coordinates = np.array(tracking_coordinates)
                        fps_array = np.array(fps_list)
                        fps_mean = np.mean(fps_array)
                        # print("fps_mean=", fps_mean)
                        with open(os.path.join(results_dir, 'xy.npy'), 'wb') as f:
                            np.save(f, tracking_coordinates)
                        write_np_array_to_txt_file(tracking_coordinates, os.path.join(results_dir, "target_point.txt"))
                        with open(os.path.join(results_dir, 'fps_mean.npy'), 'wb') as f:
                            np.save(f, fps_mean)

                        raise Exception("The query template is too close to the image border, or the template has totaly drifted away")

                    x_query, y_query = 32 + flow[0, 0, 32, 32], 32 + flow[0, 1, 32, 32]
                    x_query_int, y_query_int = int(round(x_query)), int(round(y_query))

                    # query===>reference
                    if not (x_query_int >= 0 and x_query_int <= 63 and y_query_int >= 0 and y_query_int <= 63):
                        tracking_coordinates = np.array(tracking_coordinates)
                        fps_array = np.array(fps_list)
                        fps_mean = np.mean(fps_array)
                        # print("fps_mean=", fps_mean)
                        with open(os.path.join(results_dir, 'xy.npy'), 'wb') as f:
                            np.save(f, tracking_coordinates)
                        write_np_array_to_txt_file(tracking_coordinates, os.path.join(results_dir, "target_point.txt"))
                        with open(os.path.join(results_dir, 'fps_mean.npy'), 'wb') as f:
                            np.save(f, fps_mean)

                        raise Exception("The target point is likely to be missed.")
                    else:
                        x_back_to_reference, y_back_to_reference = \
                            x_query_int + flow[1, 0, y_query_int, x_query_int], y_query_int + flow[
                                1, 1, y_query_int, x_query_int]

                    d_back = \
                        math.sqrt((x_back_to_reference - 32) * (x_back_to_reference - 32) +
                                  (y_back_to_reference - 32) * (y_back_to_reference - 32))

                    if d_back < 2:
                        offset_x = flow[0, 0, 32, 32] + tracking_cross_x_int - tracking_cross_x_old
                        offset_y = flow[0, 1, 32, 32] + tracking_cross_y_int - tracking_cross_y_old
                        tracking_template_1.target_point[0] += offset_x
                        tracking_template_1.target_point[1] += offset_y
                        drift_corrected += 1
                        if allow_reinitialize_template and (abs(offset_x) > 3 or abs(offset_y) > 3):
                            # 更正后的跟踪点为
                            tracking_template_1 = \
                                tracking_template_0.reinitialize_template(
                                    (tracking_cross_x_old + offset_x, tracking_cross_y_old + offset_y),
                                    img, global_bbox=global_bbox)
                            # 重新设置模板0
                            tracking_template_0.width = tracking_template_1.width
                            tracking_template_0.height = tracking_template_1.height
                            tracking_template_0.template = tracking_template_1.template.clone()
                            tracking_template_0.mask = tracking_template_1.mask.clone()
                            tracking_template_0.target_point = tracking_template_1.target_point.copy()
                            tracking_template_0.polygon = tracking_template_1.polygon.copy()  # 以模板为参考系
                            tracking_template_0.pose = tracking_template_1.pose.copy()
                            tracking_template_0.bbox_center = (
                            tracking_template_1.bbox_center[0], tracking_template_1.bbox_center[1])

                        densematchig_corrected = True

            ## show results
            if batch_idx >= 1:
                tracking_coordinates.append([tracking_cross_x, tracking_cross_y])
                tracking_cross_x, tracking_cross_y = int(round(tracking_cross_x)), int(round(tracking_cross_y))
                # Calculate Frames per second (FPS)
                fps = cv2.getTickFrequency() / (cv2.getTickCount() - timer)
                fps_list.append(fps)
                # 粗跟踪框
                if not allow_indepedent_tracking:
                    p1 = (int(global_bbox[0]), int(global_bbox[1]))
                    p2 = (int(global_bbox[0] + global_bbox[2]), int(global_bbox[1] + global_bbox[3]))
                    cv2.rectangle(current_frame, p1, p2, (255, 255, 255), 2, 1)
                # 精跟踪框
                p3 = (int(tracking_box[0]), int(tracking_box[1]))
                p4 = (int(tracking_box[0] + tracking_box[2]), int(tracking_box[1] + tracking_box[3]))
                cv2.rectangle(current_frame, p3, p4, (255, 0, 0), 2, 1)
                cv2.line(current_frame, (tracking_cross_x - 3, tracking_cross_y),
                         (tracking_cross_x + 3, tracking_cross_y), (0, 0, 127), 2, cv2.LINE_AA)
                cv2.line(current_frame, (tracking_cross_x, tracking_cross_y - 3),
                         (tracking_cross_x, tracking_cross_y + 3), (0, 0, 127), 2, cv2.LINE_AA)
                cv2.putText(current_frame, "Times template changed: " + str(int(template_updated)), (100, 20),
                            cv2.FONT_HERSHEY_SIMPLEX, 0.75, (0, 0, 255),
                            2)
                cv2.putText(current_frame, "Tracking frame: " + str(int(batch_idx)), (100, 50),
                            cv2.FONT_HERSHEY_SIMPLEX, 0.75, (0, 0, 255),
                            2)
                cv2.putText(current_frame, "Template size changed: " + str(int(num_template_sz_changed)), (100, 80),
                            cv2.FONT_HERSHEY_SIMPLEX, 0.75, (0, 0, 255),
                            2)
                cv2.putText(current_frame, "Times drift corrected: " + str(int(drift_corrected)), (100, 110),
                            cv2.FONT_HERSHEY_SIMPLEX, 0.75, (0, 0, 255),
                            2)
                # Display FPS on frame
                cv2.putText(current_frame, "FPS : " + str(int(fps)), (100, 140), cv2.FONT_HERSHEY_SIMPLEX, 0.75,
                            (0, 0, 255),
                            2)
                # Display result
                cv2.imshow("Tracking", current_frame)
                cv2.imwrite(os.path.join(results_dir, str(batch_idx) + '.jpg'), current_frame)

                if not allow_indepedent_tracking:
                    global_bbox_center_x = global_bbox[0] + 0.5 * global_bbox[2]
                    global_bbox_center_y = global_bbox[1] + 0.5 * global_bbox[3]
                    diff_between_global_and_local_x = abs(global_bbox_center_x - tracking_cross_x)
                    diff_between_global_and_local_y = abs(global_bbox_center_y - tracking_cross_y)

                    if diff_between_global_and_local_x >= 0.5 * global_bbox[
                        2] or diff_between_global_and_local_y >= 0.5 * \
                            global_bbox[3]:
                        print("The target point tracking failed")
                        break

                # Exit if ESC pressed
                if cv2.waitKey(1) & 0xFF == ord('q'):  # if press SPACE bar
                    break

        # cv2.waitKey(0)
        cv2.destroyAllWindows()

        tracking_coordinates = np.array(tracking_coordinates)
        fps_array = np.array(fps_list)
        fps_mean = np.mean(fps_array)
        # print("fps_mean=", fps_mean)
        with open(os.path.join(results_dir, 'xy.npy'), 'wb') as f:
            np.save(f, tracking_coordinates)

        write_np_array_to_txt_file(tracking_coordinates, os.path.join(results_dir, "target_point.txt"))

        with open(os.path.join(results_dir, 'fps_mean.npy'), 'wb') as f:
            np.save(f, fps_mean)
