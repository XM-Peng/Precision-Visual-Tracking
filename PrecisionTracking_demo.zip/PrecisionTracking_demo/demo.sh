#!/bin/bash
#python tracking_stark_iclk_densecorrect_glocalNet_args.py -path ./test/lonetree_difftex_x2/right -x 910 -y 57 -tlx 853 -tly 10 -bw 96 -bh 96
python tracking_stark_iclk_densecorrect_glocalNet_args.py -path ./test/a_rain_of_stones_x2/left -x 659 -y 140 -tlx 579 -tly 81 -bw 120 -bh 120

#python tracking_stark_iclk_densecorrect_glocalNet_args_simplified.py -path /media/psdz/Data/synthetic/5be883a4f98cee15019d5b83/funnyworld_x2/left/images -x 896 -y 54 -tlx 817 -tly 10 -bw 132 -bh 132
#python tracking_stark_iclk_densecorrect_glocalNet_args_simplified.py -path /media/psdz/Data/synthetic/5be883a4f98cee15019d5b83/lonetree_augmented1_x2/left/images -x 75 -y 46 -tlx 10 -tly 10 -bw 108 -bh 108
