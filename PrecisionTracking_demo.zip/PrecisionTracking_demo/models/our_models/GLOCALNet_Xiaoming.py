import torch
import torch.nn as nn
import numpy as np
from models.feature_backbones.VGG_features_Xiaoming import VGGPyramid
from .mod import CMDTop
from models.our_models.mod import OpticalFlowEstimator, FeatureL2Norm, \
    CorrelationVolume, deconv, conv, predict_flow, unnormalise_and_convert_mapping_to_flow
import torch.nn.functional as F
from models.correlation import correlation # the custom cost volume layer
from .bilinear_deconv import BilinearConvTranspose2d


class GLOCALNet_model(nn.Module):
    '''
    GLOCAL-Net
    '''
    def __init__(self, evaluation, div=1.0, refinement=True, refinement_32=False, batch_norm=True, residual=True,
                 pyramid_type='VGG', md=4, input_decoder='flow_and_feat'):
        """
        input: md --- maximum displacement (for correlation. default: 4), after warpping

        """
        super(GLOCALNet_model, self).__init__()
        self.div=div
        self.refinement=refinement
        self.refinement_32 = refinement_32
        self.residual = residual
        self.pyramid_type = pyramid_type

        self.input_decoder = input_decoder
        self.leakyRELU = nn.LeakyReLU(0.1)
        # 指定相关计算为
        # Convolutional neural network architecture for geometric matching实现方法
        self.corr = CorrelationVolume()

        # L2 feature normalisation, 沿着通道C进行l2归一化
        self.l2norm = FeatureL2Norm()

        dd = np.cumsum([128,128,96,64,32])
        # weights for decoder at different levels

        nd = 16*16 # global correlation
        od = nd + 2
        self.decoder4 = CMDTop(in_channels=od, bn=batch_norm)
        # initialize the deconv to bilinear weights speeds up the training significantly
        self.deconv4 = BilinearConvTranspose2d(2, 2, kernel_size=4, stride=2, padding=1)
        # self.deconv4 = deconv(2, 2, kernel_size=4, stride=2, padding=1)

        nd = (2*md+1)**2 # constrained correlation, 4 pixels on each side
        if self.input_decoder == 'flow_and_feat':
            od = nd + 2 # 需要将2通道的flow串接到nd个通道的feature上面
        else:
            raise Exception("self.input_decoder must be 'flow_and_feat'")

        self.decoder3 = OpticalFlowEstimator(in_channels=od, batch_norm=batch_norm)

        # initialize the deconv to bilinear weights speeds up the training significantly
        self.deconv3 = BilinearConvTranspose2d(2, 2, kernel_size=4, stride=2, padding=1)
        # self.deconv3 = deconv(2, 2, kernel_size=4, stride=2, padding=1)
        # 普通的反卷积
        self.upfeat3 = deconv(od+dd[4], 2, kernel_size=4, stride=2, padding=1)
        if self.refinement_32:
            self.dc_conv1_level3 = conv(od + dd[4], 128, kernel_size=3, stride=1, padding=1, dilation=1,
                                        batch_norm=batch_norm)
            self.dc_conv2_level3 = conv(128, 128, kernel_size=3, stride=1, padding=2, dilation=2,
                                        batch_norm=batch_norm)
            self.dc_conv3_level3 = conv(128, 128, kernel_size=3, stride=1, padding=4, dilation=4,
                                        batch_norm=batch_norm)
            self.dc_conv4_level3 = conv(128, 96, kernel_size=3, stride=1, padding=8, dilation=8,
                                        batch_norm=batch_norm)
            self.dc_conv5_level3 = conv(96, 64, kernel_size=3, stride=1, padding=16, dilation=16,
                                        batch_norm=batch_norm)
            self.dc_conv6_level3 = conv(64, 32, kernel_size=3, stride=1, padding=1, dilation=1,
                                        batch_norm=batch_norm)
            self.dc_conv7_level3 = predict_flow(32)

        nd = (2*md+1)**2 # constrained correlation, 4 pixels on each side
        if self.input_decoder == 'flow_and_feat':
            od = nd + 4
        else:
            raise Exception("self.input_decoder must be 'flow_and_feat'")

        self.decoder2 = OpticalFlowEstimator(in_channels=od, batch_norm=batch_norm)
        self.deconv2 = deconv(2, 2, kernel_size=4, stride=2, padding=1)

        # weights for refinement module
        self.dc_conv1 = conv(od+dd[4], 128, kernel_size=3, stride=1, padding=1,  dilation=1, batch_norm=batch_norm)
        self.dc_conv2 = conv(128,      128, kernel_size=3, stride=1, padding=2,  dilation=2, batch_norm=batch_norm)
        self.dc_conv3 = conv(128,      128, kernel_size=3, stride=1, padding=4,  dilation=4, batch_norm=batch_norm)
        self.dc_conv4 = conv(128,      96,  kernel_size=3, stride=1, padding=8,  dilation=8, batch_norm=batch_norm)
        self.dc_conv5 = conv(96,       64,  kernel_size=3, stride=1, padding=16, dilation=16, batch_norm=batch_norm)
        self.dc_conv6 = conv(64,       32,  kernel_size=3, stride=1, padding=1,  dilation=1, batch_norm=batch_norm)
        self.dc_conv7 = predict_flow(32) # 就是一个卷积层

        # 初始化卷积层
        for m in self.modules():
            if isinstance(m, nn.Conv2d):
                nn.init.kaiming_normal_(m.weight.data, mode='fan_in')
                if m.bias is not None:
                    m.bias.data.zero_()
        if pyramid_type == 'VGG':
            self.pyramid = VGGPyramid()
        else:
            raise ValueError("No other back-bone implemented, please choose VGG")

        self.evaluation=evaluation

    def warp(self, x, flo):
        """
        warp an image/tensor (im2) back to im1, according to the optical flow

        x: [B, C, H, W] (im2)
        flo: [B, 2, H, W] flow

        """
        B, C, H, W = x.size()
        # mesh grid
        xx = torch.arange(0, W).view(1, -1).repeat(H, 1)
        yy = torch.arange(0, H).view(-1, 1).repeat(1, W)
        xx = xx.view(1, 1, H, W).repeat(B, 1, 1, 1)
        yy = yy.view(1, 1, H, W).repeat(B, 1, 1, 1)
        grid = torch.cat((xx, yy),1).float()

        if x.is_cuda:
            grid = grid.cuda()
        vgrid = grid + flo
        # makes a mapping out of the flow

        # scale grid to [-1,1]
        vgrid[:, 0, :, :] = 2.0 * vgrid[:, 0, :, :].clone() / max(W-1, 1) - 1.0
        vgrid[:, 1, :, :] = 2.0 * vgrid[:, 1, :, :].clone() / max(H-1, 1) - 1.0

        vgrid = vgrid.permute(0, 2, 3, 1)

        if float(torch.__version__[:3]) >= 1.3:
            output = nn.functional.grid_sample(x, vgrid, align_corners=True)
        else:
            output = nn.functional.grid_sample(x, vgrid)

        # 经过warping后的x
        return output

    def forward(self, im_target, im_source, w_original=256, h_original=256):
        # im_target is target image ==> corresponds to all the indices 1,
        # im_source is source image ==> corresponds to all the indices 2

        b, _, h_original, w_original = im_target.size()
        div = self.div
        if self.pyramid_type == 'VGG':
            im1_pyr = self.pyramid(im_target)
            im2_pyr = self.pyramid(im_source)
            c14=im1_pyr[-1] # Nx512x16x16
            c24=im2_pyr[-1] # Nx512x16x16
            c13=im1_pyr[-2] # Nx512x32x32
            c23=im2_pyr[-2] # Nx512x32x32
            c12=im1_pyr[-3] # Nx512x64x64
            c22=im2_pyr[-3] # Nx512x64x64
        else:
            raise ValueError("No other back-bone implemented, please choose VGG")

        # level 16x16, global correlation
        # 在进行全局相关操作之前，先对c24和c14进行l2归一化，论文中的公式(3)
        corr4 = self.corr(self.l2norm(c24), self.l2norm(c14))
        corr4 = self.l2norm(F.relu(corr4)) # Nx256x16x16
        b, c, h, w = corr4.size()
        ratio_x = w / float(w_original)
        ratio_y = h / float(h_original)
        if torch.cuda.is_available():
            init_map = torch.FloatTensor(b, 2, h, w).zero_().cuda() # Nx2x16x16
        else:
            init_map = torch.FloatTensor(b, 2, h, w).zero_()

        # 以global correlation作为输入，估计flow,对x1的通道数目没有限制
        est_map4 = self.decoder4(x1=corr4, x3=init_map) # Nx2x16x16

        # conversion to flow and from there PWCNet
        flow4 = unnormalise_and_convert_mapping_to_flow(est_map4) / self.div # Nx2x16x16
        # 为了估计以原图像大小(256)上面的flow，需要将flow4的数值按比例拉伸
        flow4[:, 0, :, :] /= ratio_x
        flow4[:, 1, :, :] /= ratio_y
        # 反卷积将图像放大一倍
        up_flow4 = self.deconv4(flow4) # Nx2x32x32

        # level 32x32
        ratio_x = up_flow4.shape[3] / float(w_original)
        ratio_y = up_flow4.shape[2] / float(h_original)
        up_flow_4_warping = up_flow4 * div # Nx2x32x32

        ## 目前up_flow_4_warping代表的flow已经是基于原图像大小(256)，
        ## 为了在当前分辨率下操作，需要缩放到对应当前分辨率
        up_flow_4_warping[:, 0, :, :] *= ratio_x
        up_flow_4_warping[:, 1, :, :] *= ratio_y

        # 对source image的c23进行warping
        warp3 = self.warp(c23, up_flow_4_warping) # Nx256x32x32

        # constrained correlation now
        corr3 = correlation.FunctionCorrelation(tensorFirst=c13, tensorSecond=warp3) # Nx81xHxW
        corr3 = self.leakyRELU(corr3) # 81的出处是(4*2+1)^2
        if self.input_decoder == 'flow_and_feat':
            corr3 = torch.cat((corr3, up_flow4), 1) # 将2通道的flow串接到81通道的feature上面，Nx83xHxW
        else:
            raise Exception("self.input_decoder must be 'flow_and_feat'")

        # decoder3的输入要求通道数目是83；x3是corr3经过层层卷积后的结果，Nx531x32x32
        # res_flow3是以其为输入再卷积得到的输出, Nx2x32x32
        x3, res_flow3 = self.decoder3(corr3)
        if self.residual: # res_flow3是残差
            flow3 = res_flow3 + up_flow4 # Nx2x32x32
        else:
            flow3 = res_flow3
        if self.refinement_32: # 是否在32x32分辨率上进行细化
            x = self.dc_conv4_level3(self.dc_conv3_level3(self.dc_conv2_level3(self.dc_conv1_level3(x3))))
            flow3 = flow3 + self.dc_conv7_level3(self.dc_conv6_level3(self.dc_conv5_level3(x)))

        up_flow3 = self.deconv3(flow3) # 反卷积将flow3扩大1倍分辨率， Nx2x64x64
        up_feat3 = self.upfeat3(x3) # 反卷积将x3扩大1倍分辨率, 同时降低其通道数目，得到Nx2x64x64

        # level 64x64
        ## 目前up_flow3代表的flow已经是基于原图像大小(256)，
        ## 为了在当前分辨率下操作，需要缩放到对应当前分辨率
        ratio_x = up_flow3.shape[3] / float(w_original)
        ratio_y = up_flow3.shape[2] / float(h_original)
        up_flow_3_warping = up_flow3 * div
        up_flow_3_warping[:, 0, :, :] *= ratio_x
        up_flow_3_warping[:, 1, :, :] *= ratio_y

        # 根据up_flow_3_warping来warping c22
        warp2 = self.warp(c22, up_flow_3_warping) # Nx128x64x64
        # local correlation
        corr2 = correlation.FunctionCorrelation(tensorFirst=c12, tensorSecond=warp2) # Nx81x64x64
        corr2 = self.leakyRELU(corr2)

        if self.input_decoder == 'flow_and_feat':
            corr2 = torch.cat((corr2, up_flow3, up_feat3), 1) # Nx85x64x64
        else:
            raise Exception("self.input_decoder must be 'flow_and_feat'")

        # x是corr2经过层层卷积后的结果，Nx533x64x64
        # res_flow2是以其为输入再卷积得到的输出, Nx2x64x64
        x, res_flow2 = self.decoder2(corr2)
        if self.residual:
            flow2 = res_flow2 + up_flow3  # Nx2x64x64
        else:
            flow2 = res_flow2

        if self.refinement:
            x = self.dc_conv4(self.dc_conv3(self.dc_conv2(self.dc_conv1(x)))) # Nx96x64x64
            flow2 = flow2 + self.dc_conv7(self.dc_conv6(self.dc_conv5(x))) # Nx2x64x64

        if self.evaluation:
            return flow2
        else: # flow4, flow3, flow2都是基于原图像大小(256)，但是分辨率不同
            return [flow4, flow3, flow2]



